import { getContentById } from '../data/content';
import BackButton from '../components/BackButton';

interface ContentPageProps {
  id: string;
  onBack: () => void;
  onHome: () => void;
}

const categoryStyles = {
  direitos: { bg: 'bg-[#EEF2FA]', text: 'text-[#1B3A6B]', dot: 'bg-[#1B3A6B]' },
  agentes: { bg: 'bg-[#ECFDF5]', text: 'text-[#065F46]', dot: 'bg-[#009C5B]' },
  leis: { bg: 'bg-[#F5F3FF]', text: 'text-[#5B21B6]', dot: 'bg-[#7C3AED]' },
};

export default function ContentPage({ id, onBack, onHome }: ContentPageProps) {
  const entry = getContentById(id);

  if (!entry) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <p className="text-[#6B7A8D] mb-4">Conteúdo não encontrado.</p>
        <button onClick={onHome} className="text-[#1B3A6B] font-medium hover:underline">
          Voltar ao início
        </button>
      </div>
    );
  }

  const styles = categoryStyles[entry.categoryId] || categoryStyles.leis;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      {/* Breadcrumb & back */}
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button
          onClick={onHome}
          className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150"
        >
          Início
        </button>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full ${styles.bg} ${styles.text}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${styles.dot}`} />
            {entry.category}
          </span>
        </div>
        <h1 className="font-display text-3xl md:text-4xl text-[#0F1C2E] leading-tight mb-4">
          {entry.title}
        </h1>
        <p className="text-[#6B7A8D] text-base leading-relaxed border-l-4 border-[#009C5B] pl-4">
          {entry.summary}
        </p>
      </div>

      {/* Sections */}
      <div className="space-y-6">
        {entry.sections.map((section, i) => (
          <div
            key={i}
            className={`rounded-2xl border ${
              section.highlight
                ? 'bg-[#FFFBEB] border-[#F59E0B]/30'
                : 'bg-white border-[#D5DCE8]'
            } p-6`}
          >
            <h2 className={`font-semibold text-base mb-3 ${section.highlight ? 'text-[#92400E]' : 'text-[#1B3A6B]'}`}>
              {section.highlight && (
                <span className="mr-2">⚠️</span>
              )}
              {section.title}
            </h2>

            {section.content && (
              <p className={`text-sm leading-relaxed ${section.highlight ? 'text-[#78350F]' : 'text-[#374151]'}`}>
                {section.content}
              </p>
            )}

            {section.items && section.items.length > 0 && (
              <ul className="space-y-2 mt-2">
                {section.items.map((item, j) => (
                  <li key={j} className="flex items-start gap-2.5">
                    <span className={`mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0 ${section.highlight ? 'bg-[#F59E0B]' : 'bg-[#009C5B]'}`} />
                    <span className={`text-sm leading-relaxed ${section.highlight ? 'text-[#78350F]' : 'text-[#374151]'}`}>
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>

      {/* Footer cta */}
      <div className="mt-8 p-5 bg-[#EEF2FA] rounded-2xl border border-[#D5DCE8] flex items-center justify-between flex-wrap gap-4">
        <div>
          <p className="font-semibold text-[#1B3A6B] text-sm">Quer aprender mais?</p>
          <p className="text-xs text-[#6B7A8D] mt-0.5">Explore os outros temas ou faça o quiz.</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onBack}
            className="text-sm font-medium text-[#1B3A6B] hover:text-[#009C5B] transition-colors duration-150"
          >
            ← Voltar
          </button>
          <button
            onClick={onHome}
            className="text-sm font-medium bg-[#1B3A6B] text-white px-4 py-2 rounded-lg hover:bg-[#254d8c] transition-colors duration-150"
          >
            Página inicial
          </button>
        </div>
      </div>
    </div>
  );
}
