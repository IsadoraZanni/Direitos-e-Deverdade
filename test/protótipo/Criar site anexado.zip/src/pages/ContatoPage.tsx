import { useState } from 'react';
import BackButton from '../components/BackButton';

interface ContatoPageProps {
  onBack: () => void;
  onHome: () => void;
}

export default function ContatoPage({ onBack, onHome }: ContatoPageProps) {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSent(true);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button onClick={onHome} className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150">Início</button>
      </div>

      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#EEF2FA] text-[#1B3A6B] mb-3">
          Quem somos
        </span>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-2">Contato</h1>
        <p className="text-[#6B7A8D] text-sm leading-relaxed">
          Entre em contato conosco para dúvidas, sugestões ou contribuições ao projeto.
        </p>
      </div>

      {/* Contact info */}
      <div className="bg-[#EEF2FA] rounded-2xl p-5 mb-6 flex items-center gap-4">
        <div className="w-10 h-10 bg-[#1B3A6B] rounded-xl flex items-center justify-center flex-shrink-0">
          <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
            <polyline points="22,6 12,13 2,6" />
          </svg>
        </div>
        <div>
          <p className="text-xs text-[#6B7A8D] font-medium">E-mail</p>
          <p className="text-sm font-semibold text-[#1B3A6B]">contato@direitosdeverdade.org</p>
        </div>
      </div>

      {sent ? (
        <div className="bg-[#ECFDF5] rounded-2xl border border-[#009C5B]/30 p-8 text-center">
          <div className="text-4xl mb-3">✉️</div>
          <h2 className="font-display text-2xl text-[#065F46] mb-2">Mensagem enviada!</h2>
          <p className="text-sm text-[#065F46]/80 mb-5">
            Obrigado pelo contato. Responderemos em breve.
          </p>
          <button
            onClick={() => setSent(false)}
            className="text-sm font-medium text-[#009C5B] hover:text-[#007a47] transition-colors duration-150"
          >
            Enviar outra mensagem
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-[#D5DCE8] p-6 space-y-5">
          <div>
            <label className="block text-sm font-medium text-[#0F1C2E] mb-1.5" htmlFor="name">
              Nome <span className="text-[#DC2626]">*</span>
            </label>
            <input
              id="name"
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Seu nome completo"
              required
              className="w-full px-4 py-3 rounded-xl border border-[#D5DCE8] text-sm text-[#0F1C2E] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1B3A6B]/30 focus:border-[#1B3A6B] transition-all duration-150"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0F1C2E] mb-1.5" htmlFor="email">
              E-mail <span className="text-[#DC2626]">*</span>
            </label>
            <input
              id="email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="seu@email.com"
              required
              className="w-full px-4 py-3 rounded-xl border border-[#D5DCE8] text-sm text-[#0F1C2E] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1B3A6B]/30 focus:border-[#1B3A6B] transition-all duration-150"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0F1C2E] mb-1.5" htmlFor="message">
              Mensagem <span className="text-[#DC2626]">*</span>
            </label>
            <textarea
              id="message"
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Escreva sua mensagem, dúvida ou sugestão..."
              required
              rows={5}
              className="w-full px-4 py-3 rounded-xl border border-[#D5DCE8] text-sm text-[#0F1C2E] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1B3A6B]/30 focus:border-[#1B3A6B] transition-all duration-150 resize-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-xl bg-[#1B3A6B] text-white font-semibold text-sm hover:bg-[#254d8c] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#1B3A6B]/50"
          >
            Enviar mensagem
          </button>
        </form>
      )}
    </div>
  );
}
