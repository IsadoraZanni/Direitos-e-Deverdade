import BackButton from '../components/BackButton';

type Section = 'sobre' | 'missao' | 'equipe';

interface QuemSomosPageProps {
  section: Section;
  onBack: () => void;
  onHome: () => void;
}

const teamMembers = [
  { name: 'Ana Paula Rodrigues', role: 'Coordenadora do Projeto', area: 'Direito Constitucional', initials: 'AP' },
  { name: 'Carlos Eduardo Lima', role: 'Desenvolvedor Web', area: 'Ciência da Computação', initials: 'CE' },
  { name: 'Maria Fernanda Souza', role: 'Designer UX/UI', area: 'Design Gráfico', initials: 'MF' },
  { name: 'João Victor Alves', role: 'Pesquisador Jurídico', area: 'Direito', initials: 'JV' },
  { name: 'Larissa Mendes', role: 'Comunicação e Conteúdo', area: 'Jornalismo', initials: 'LM' },
  { name: 'Rafael Cunha', role: 'Analista de Dados', area: 'Sistemas de Informação', initials: 'RC' },
];

function SobreContent({ onBack, onHome }: { onBack: () => void; onHome: () => void }) {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button onClick={onHome} className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150">Início</button>
      </div>

      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#EEF2FA] text-[#1B3A6B] mb-3">
          Quem somos
        </span>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-4">Sobre o Projeto</h1>
        <p className="text-[#6B7A8D] text-base leading-relaxed border-l-4 border-[#009C5B] pl-4">
          O Direitos DeVerdade nasceu da observação de uma realidade: muitos brasileiros não conhecem seus próprios direitos — e quando os conhecem, não sabem como exercê-los.
        </p>
      </div>

      <div className="space-y-5">
        <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6">
          <h2 className="font-semibold text-[#1B3A6B] text-base mb-3">O que é o Direitos DeVerdade?</h2>
          <p className="text-sm text-[#374151] leading-relaxed">
            É uma plataforma educacional digital que reúne informações sobre direitos fundamentais, leis brasileiras, deveres dos cidadãos e funções dos agentes públicos — tudo em linguagem simples, acessível e organizada de forma visual.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6">
          <h2 className="font-semibold text-[#1B3A6B] text-base mb-3">Qual problema queremos resolver?</h2>
          <p className="text-sm text-[#374151] leading-relaxed mb-3">
            O acesso à informação jurídica no Brasil ainda é desigual. Quem tem condições financeiras pode contratar advogados. Mas a grande maioria da população não tem esse acesso — e muitas vezes desconhece até mesmo os órgãos públicos gratuitos que pode acionar.
          </p>
          <p className="text-sm text-[#374151] leading-relaxed">
            Além disso, a linguagem jurídica é complexa e pouco acessível para a população em geral. O Direitos DeVerdade atua como uma ponte entre a lei e o cidadão.
          </p>
        </div>

        <div className="bg-[#ECFDF5] rounded-2xl border border-[#009C5B]/30 p-6">
          <h2 className="font-semibold text-[#065F46] text-base mb-3">Por que isso é importante?</h2>
          <p className="text-sm text-[#065F46] leading-relaxed">
            Cidadãos informados participam mais da democracia, defendem melhor seus interesses e contribuem para uma sociedade mais justa. Conhecer seus direitos é o primeiro passo para exercê-los.
          </p>
        </div>
      </div>
    </div>
  );
}

function MissaoContent({ onBack, onHome }: { onBack: () => void; onHome: () => void }) {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button onClick={onHome} className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150">Início</button>
      </div>

      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#EEF2FA] text-[#1B3A6B] mb-3">
          Quem somos
        </span>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-4">Nossa Missão</h1>
      </div>

      <div className="bg-[#1B3A6B] rounded-2xl p-8 mb-6 text-white">
        <p className="font-display text-2xl text-white/90 italic leading-relaxed text-center">
          "Tornar informações sobre direitos, deveres, leis e serviços públicos mais acessíveis, compreensíveis e fáceis de encontrar — para todos os brasileiros."
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {[
          { icon: '🎯', title: 'Clareza', desc: 'Linguagem simples, sem jargões jurídicos desnecessários.' },
          { icon: '♿', title: 'Acessibilidade', desc: 'Design pensado para diferentes públicos e necessidades.' },
          { icon: '🔒', title: 'Confiabilidade', desc: 'Informações baseadas em fontes oficiais e atualizadas.' },
        ].map((v) => (
          <div key={v.title} className="bg-white rounded-2xl border border-[#D5DCE8] p-5 text-center">
            <div className="text-3xl mb-2">{v.icon}</div>
            <p className="font-semibold text-[#1B3A6B] mb-1">{v.title}</p>
            <p className="text-xs text-[#6B7A8D] leading-relaxed">{v.desc}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6">
        <h2 className="font-semibold text-[#1B3A6B] mb-3">Nossos valores</h2>
        <ul className="space-y-2">
          {[
            'Transparência — as informações são baseadas em fontes verificáveis e estão citadas.',
            'Educação — acreditamos que conhecimento é um direito, não um privilégio.',
            'Inclusão — o site é pensado para ser acessível a pessoas com diferentes níveis de escolaridade.',
            'Imparcialidade — não defendemos posições políticas. Nosso foco é a lei e os direitos do cidadão.',
          ].map((v, i) => (
            <li key={i} className="flex items-start gap-2.5">
              <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-[#009C5B] flex-shrink-0" />
              <span className="text-sm text-[#374151] leading-relaxed">{v}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function EquipeContent({ onBack, onHome }: { onBack: () => void; onHome: () => void }) {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button onClick={onHome} className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150">Início</button>
      </div>

      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#EEF2FA] text-[#1B3A6B] mb-3">
          Quem somos
        </span>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-3">Nossa Equipe</h1>
        <p className="text-[#6B7A8D] text-sm leading-relaxed">
          O Direitos DeVerdade é um projeto multidisciplinar desenvolvido por estudantes e profissionais comprometidos com a educação cívica.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {teamMembers.map((member) => (
          <div key={member.name} className="bg-white rounded-2xl border border-[#D5DCE8] p-5 flex items-start gap-4 hover:shadow-md transition-shadow duration-200">
            <div className="w-12 h-12 rounded-full bg-[#1B3A6B] flex items-center justify-center flex-shrink-0">
              <span className="text-white text-sm font-bold">{member.initials}</span>
            </div>
            <div>
              <p className="font-semibold text-[#0F1C2E] text-sm">{member.name}</p>
              <p className="text-[#009C5B] text-xs font-medium mt-0.5">{member.role}</p>
              <p className="text-[#6B7A8D] text-xs mt-1">{member.area}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function QuemSomosPage({ section, onBack, onHome }: QuemSomosPageProps) {
  if (section === 'sobre') return <SobreContent onBack={onBack} onHome={onHome} />;
  if (section === 'missao') return <MissaoContent onBack={onBack} onHome={onHome} />;
  return <EquipeContent onBack={onBack} onHome={onHome} />;
}
