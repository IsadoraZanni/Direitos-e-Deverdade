import BackButton from '../components/BackButton';

interface AvisoPageProps {
  onBack: () => void;
  onHome: () => void;
}

export default function AvisoPage({ onBack, onHome }: AvisoPageProps) {
  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button onClick={onHome} className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150">Início</button>
      </div>

      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#FEF3C7] text-[#92400E] mb-3">
          ⚠️ Aviso importante
        </span>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-4">Aviso Importante</h1>
      </div>

      <div className="bg-[#FEF3C7] border-2 border-[#F59E0B]/40 rounded-2xl p-7 mb-6 text-center">
        <div className="text-5xl mb-4">⚠️</div>
        <p className="font-display text-2xl text-[#92400E] mb-3">Finalidade Informativa e Educacional</p>
        <p className="text-[#78350F] text-base leading-relaxed">
          O conteúdo deste site <strong>não substitui orientação jurídica profissional</strong>.
        </p>
      </div>

      <div className="space-y-4">
        <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6">
          <h2 className="font-semibold text-[#1B3A6B] mb-3">O que significa isso?</h2>
          <p className="text-sm text-[#374151] leading-relaxed mb-3">
            As informações disponibilizadas no Direitos DeVerdade têm como objetivo <strong>educar e informar</strong> a população sobre direitos, deveres e leis brasileiras.
          </p>
          <p className="text-sm text-[#374151] leading-relaxed">
            No entanto, cada caso jurídico tem suas particularidades. A aplicação da lei pode variar conforme as circunstâncias específicas de cada situação, e apenas um profissional habilitado pode avaliar corretamente um caso concreto.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6">
          <h2 className="font-semibold text-[#1B3A6B] mb-3">Para questões específicas, procure:</h2>
          <ul className="space-y-2.5">
            {[
              { icon: '⚖️', text: 'Um advogado registrado na OAB (Ordem dos Advogados do Brasil)' },
              { icon: '🏛️', text: 'A Defensoria Pública — serviço gratuito para quem não pode pagar advogado' },
              { icon: '📞', text: 'O Ministério Público do seu estado ou município' },
              { icon: '🏢', text: 'O Juizado Especial Cível — para causas de até 40 salários mínimos, sem advogado' },
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="text-xl">{item.icon}</span>
                <span className="text-sm text-[#374151] leading-relaxed pt-0.5">{item.text}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-[#EEF2FA] rounded-2xl p-5">
          <p className="text-sm text-[#1B3A6B] leading-relaxed">
            <strong>Precisando de ajuda jurídica gratuita?</strong> Ligue para a Defensoria Pública do seu estado. Em muitos estados, você pode agendar atendimento pelo site ou comparecer pessoalmente.
          </p>
        </div>
      </div>
    </div>
  );
}
