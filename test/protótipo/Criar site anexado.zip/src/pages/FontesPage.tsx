import BackButton from '../components/BackButton';

interface FontesPageProps {
  onBack: () => void;
  onHome: () => void;
}

const fontes = [
  {
    categoria: 'Constituição e Legislação',
    itens: [
      { nome: 'Constituição Federal de 1988', url: 'planalto.gov.br/ccivil_03/constituicao/constituicao.htm' },
      { nome: 'Código Civil — Lei 10.406/2002', url: 'planalto.gov.br/ccivil_03/leis/2002/l10406compilada.htm' },
      { nome: 'Código Penal — Decreto-Lei 2.848/1940', url: 'planalto.gov.br/ccivil_03/decreto-lei/del2848compilado.htm' },
      { nome: 'CLT — Decreto-Lei 5.452/1943', url: 'planalto.gov.br/ccivil_03/decreto-lei/del5452.htm' },
    ],
  },
  {
    categoria: 'Estatutos e Leis Especiais',
    itens: [
      { nome: 'ECA — Lei 8.069/1990 (Estatuto da Criança e do Adolescente)', url: 'planalto.gov.br/ccivil_03/leis/l8069.htm' },
      { nome: 'CDC — Lei 8.078/1990 (Código de Defesa do Consumidor)', url: 'planalto.gov.br/ccivil_03/leis/l8078compilado.htm' },
      { nome: 'Estatuto do Idoso — Lei 10.741/2003', url: 'planalto.gov.br/ccivil_03/leis/2003/l10.741.htm' },
      { nome: 'Lei Maria da Penha — Lei 11.340/2006', url: 'planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11340.htm' },
      { nome: 'Lei Brasileira de Inclusão — Lei 13.146/2015', url: 'planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13146.htm' },
      { nome: 'Lei de Acesso à Informação — Lei 12.527/2011', url: 'planalto.gov.br/ccivil_03/_ato2011-2014/2011/lei/l12527.htm' },
      { nome: 'Lei de Responsabilidade Fiscal — LC 101/2000', url: 'planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm' },
      { nome: 'Lei de Improbidade Administrativa — Lei 8.429/1992', url: 'planalto.gov.br/ccivil_03/leis/l8429.htm' },
    ],
  },
  {
    categoria: 'Portais Oficiais',
    itens: [
      { nome: 'Senado Federal', url: 'senado.leg.br' },
      { nome: 'Câmara dos Deputados', url: 'camara.leg.br' },
      { nome: 'Supremo Tribunal Federal (STF)', url: 'stf.jus.br' },
      { nome: 'Portal do Governo Federal', url: 'gov.br' },
      { nome: 'Portal Fala.BR — Acesso à Informação', url: 'falabr.cgu.gov.br' },
      { nome: 'Consumidor.gov.br', url: 'consumidor.gov.br' },
    ],
  },
  {
    categoria: 'Órgãos de Proteção e Apoio',
    itens: [
      { nome: 'Defensoria Pública da União (DPU)', url: 'dpu.def.br' },
      { nome: 'Ministério Público Federal (MPF)', url: 'mpf.mp.br' },
      { nome: 'OAB — Ordem dos Advogados do Brasil', url: 'oab.org.br' },
      { nome: 'Procon Nacional', url: 'justica.gov.br/seus-direitos/procon' },
      { nome: 'Anvisa', url: 'anvisa.gov.br' },
      { nome: 'ANS — Agência Nacional de Saúde Suplementar', url: 'ans.gov.br' },
    ],
  },
];

export default function FontesPage({ onBack, onHome }: FontesPageProps) {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button onClick={onHome} className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150">Início</button>
      </div>

      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#EEF2FA] text-[#1B3A6B] mb-3">
          Quem somos
        </span>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-3">Fontes e Referências</h1>
        <p className="text-[#6B7A8D] text-sm leading-relaxed">
          Todo o conteúdo do Direitos DeVerdade é baseado em fontes oficiais do governo brasileiro e em legislação vigente. Consulte as fontes abaixo para aprofundar seu conhecimento.
        </p>
      </div>

      <div className="space-y-6">
        {fontes.map((grupo) => (
          <div key={grupo.categoria} className="bg-white rounded-2xl border border-[#D5DCE8] overflow-hidden">
            <div className="bg-[#EEF2FA] px-6 py-3 border-b border-[#D5DCE8]">
              <h2 className="font-semibold text-[#1B3A6B] text-sm">{grupo.categoria}</h2>
            </div>
            <ul className="divide-y divide-[#F4F6F9]">
              {grupo.itens.map((item) => (
                <li key={item.nome} className="px-6 py-3.5 flex items-center justify-between gap-4">
                  <span className="text-sm text-[#374151]">{item.nome}</span>
                  <span className="text-xs text-[#6B7A8D] whitespace-nowrap flex-shrink-0">{item.url}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-6 bg-[#FFFBEB] border border-[#F59E0B]/30 rounded-2xl p-5">
        <p className="text-sm text-[#78350F] leading-relaxed">
          <strong>Nota:</strong> As informações deste site têm base nas leis vigentes até agosto de 2026. A legislação pode ser alterada pelo Congresso Nacional. Sempre verifique a versão atualizada das leis no site do Planalto Federal.
        </p>
      </div>
    </div>
  );
}
