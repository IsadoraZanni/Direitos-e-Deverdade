import { useState } from 'react';
import { cardsData } from '../data/content';
import type { Page } from '../App';

interface HomePageProps {
  onNavigate: (page: Page) => void;
}

function ScaleIcon() {
  return (
    <svg viewBox="0 0 48 48" fill="none" className="w-12 h-12" aria-hidden="true">
      <circle cx="24" cy="24" r="24" fill="#EEF2FA" />
      <path d="M24 10v28M14 38h20" stroke="#1B3A6B" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M24 13l-8 12h16L24 13z" fill="#1B3A6B" fillOpacity="0.15" stroke="#1B3A6B" strokeWidth="2" strokeLinejoin="round" />
      <path d="M24 13l8 12H16L24 13z" fill="#1B3A6B" fillOpacity="0.08" stroke="#1B3A6B" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

function BuildingIcon() {
  return (
    <svg viewBox="0 0 48 48" fill="none" className="w-12 h-12" aria-hidden="true">
      <circle cx="24" cy="24" r="24" fill="#EEF2FA" />
      <rect x="11" y="24" width="26" height="14" rx="1" stroke="#1B3A6B" strokeWidth="2.5" fill="#1B3A6B" fillOpacity="0.08" />
      <path d="M11 24l13-12 13 12" stroke="#1B3A6B" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      <rect x="20" y="30" width="8" height="8" rx="0.5" stroke="#1B3A6B" strokeWidth="2" fill="#1B3A6B" fillOpacity="0.15" />
    </svg>
  );
}

function BookIcon() {
  return (
    <svg viewBox="0 0 48 48" fill="none" className="w-12 h-12" aria-hidden="true">
      <circle cx="24" cy="24" r="24" fill="#EEF2FA" />
      <path d="M13 12h9c1.1 0 2 .9 2 2v20a2 2 0 01-2 2H13V12z" fill="#1B3A6B" fillOpacity="0.12" stroke="#1B3A6B" strokeWidth="2" strokeLinejoin="round" />
      <path d="M35 12h-9c-1.1 0-2 .9-2 2v20a2 2 0 002 2h9V12z" fill="#1B3A6B" fillOpacity="0.06" stroke="#1B3A6B" strokeWidth="2" strokeLinejoin="round" />
      <path d="M24 14v20" stroke="#1B3A6B" strokeWidth="1.5" strokeDasharray="2 2" />
    </svg>
  );
}

function HelpIcon() {
  return (
    <svg viewBox="0 0 48 48" fill="none" className="w-12 h-12" aria-hidden="true">
      <circle cx="24" cy="24" r="24" fill="#EEF2FA" />
      <circle cx="24" cy="24" r="11" stroke="#1B3A6B" strokeWidth="2.5" fill="#1B3A6B" fillOpacity="0.08" />
      <path d="M21.5 19.5a3 3 0 115 2.83C25.5 23.5 24 24.5 24 26" stroke="#1B3A6B" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="24" cy="29.5" r="1.25" fill="#1B3A6B" />
    </svg>
  );
}

const icons: Record<string, React.ReactNode> = {
  scale: <ScaleIcon />,
  building: <BuildingIcon />,
  book: <BookIcon />,
  help: <HelpIcon />,
};

const categoryColors = {
  direitos: { border: 'border-[#1B3A6B]', badge: 'bg-[#1B3A6B] text-white', mini: 'hover:bg-[#1B3A6B]' },
  agentes: { border: 'border-[#009C5B]', badge: 'bg-[#009C5B] text-white', mini: 'hover:bg-[#009C5B]' },
  leis: { border: 'border-[#7C3AED]', badge: 'bg-[#7C3AED] text-white', mini: 'hover:bg-[#7C3AED]' },
  onde: { border: 'border-[#B45309]', badge: 'bg-[#B45309] text-white', mini: 'hover:bg-[#B45309]' },
};

export default function HomePage({ onNavigate }: HomePageProps) {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  const handleMinicard = (id: string, isOndeVou?: boolean) => {
    if (isOndeVou) {
      onNavigate({ type: 'onde-vou', id });
    } else {
      onNavigate({ type: 'content', id });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-16">
      {/* Hero */}
      <div className="text-center mb-12 pt-2">
        <div className="inline-flex items-center gap-2 bg-[#EEF2FA] text-[#1B3A6B] text-xs font-semibold px-3 py-1.5 rounded-full mb-4 tracking-wide uppercase">
          <span className="w-1.5 h-1.5 rounded-full bg-[#009C5B] inline-block" />
          Informação Cidadã
        </div>
        <h1 className="font-display text-4xl md:text-5xl text-[#0F1C2E] mb-4 leading-tight">
          Seus direitos,{' '}
          <span className="text-[#1B3A6B]">de verdade</span>
        </h1>
        <p className="text-[#6B7A8D] text-lg max-w-2xl mx-auto leading-relaxed">
          Acesse informações sobre direitos, deveres, leis e funções dos agentes públicos — em linguagem simples, sem termos jurídicos complicados.
        </p>
      </div>

      {/* Main Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {cardsData.map((card) => {
          const isExpanded = hoveredCard === card.id;
          const colors = categoryColors[card.categoryId as keyof typeof categoryColors] || categoryColors.direitos;

          return (
            <div
              key={card.id}
              onMouseEnter={() => setHoveredCard(card.id)}
              onMouseLeave={() => setHoveredCard(null)}
              onClick={() => setHoveredCard(isExpanded ? null : card.id)}
              className={`bg-white rounded-2xl border-2 transition-all duration-300 cursor-default select-none ${
                isExpanded
                  ? `${colors.border} shadow-2xl shadow-black/10`
                  : 'border-[#D5DCE8] shadow-md hover:shadow-xl'
              }`}
              role="region"
              aria-label={card.title}
            >
              {/* Card header */}
              <div className={`p-6 transition-all duration-300 ${isExpanded ? 'pb-4' : ''}`}>
                <div className="flex items-start gap-4">
                  <div className={`flex-shrink-0 transition-transform duration-300 ${isExpanded ? 'scale-105' : ''}`}>
                    {icons[card.icon]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className={`inline-block text-xs font-bold px-2.5 py-1 rounded-full mb-2 ${colors.badge}`}>
                      {card.categoryId === 'direitos' && 'Direitos'}
                      {card.categoryId === 'agentes' && 'Agentes Públicos'}
                      {card.categoryId === 'leis' && 'Leis'}
                      {card.categoryId === 'onde' && 'Orientação'}
                    </div>
                    <h2 className="font-display text-xl text-[#0F1C2E] leading-snug mb-1.5">
                      {card.title}
                    </h2>
                    <p className="text-[#6B7A8D] text-sm leading-relaxed">
                      {card.description}
                    </p>
                  </div>
                </div>

                {!isExpanded && (
                  <div className="mt-4 flex items-center gap-1.5 text-xs text-[#6B7A8D]">
                    <svg viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
                      <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                      <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                    </svg>
                    Passe o mouse para ver as opções
                  </div>
                )}
              </div>

              {/* Minicards */}
              <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${
                  isExpanded ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="px-6 pb-6">
                  <div className="pt-2 border-t border-[#F0F2F5] mb-3">
                    <p className="text-xs font-semibold text-[#6B7A8D] uppercase tracking-wide pt-3">
                      Selecione um tema
                    </p>
                  </div>
                  <div className="flex flex-col gap-2">
                    {card.minicards.map((minicard) => (
                      <button
                        key={minicard.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMinicard(minicard.id, minicard.isOndeVou);
                        }}
                        className={`text-left w-full px-4 py-3 rounded-xl bg-[#F4F6F9] ${colors.mini} hover:text-white transition-all duration-200 flex items-center justify-between group focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-[#1B3A6B]/30`}
                      >
                        <span className="text-sm font-medium text-[#0F1C2E] group-hover:text-white transition-colors duration-200">
                          {minicard.title}
                        </span>
                        <svg
                          viewBox="0 0 20 20"
                          fill="currentColor"
                          className="w-4 h-4 flex-shrink-0 ml-2 text-[#6B7A8D] group-hover:text-white/80 group-hover:translate-x-0.5 transition-all duration-200"
                        >
                          <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                        </svg>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Info banner */}
      <div className="mt-10 bg-[#FFF9EC] border border-[#F59E0B]/30 rounded-2xl p-5 flex items-start gap-4">
        <div className="flex-shrink-0 w-8 h-8 bg-[#F59E0B]/15 rounded-lg flex items-center justify-center">
          <svg viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 text-[#B45309]">
            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
        </div>
        <div>
          <p className="text-sm font-semibold text-[#92400E] mb-0.5">Aviso importante</p>
          <p className="text-sm text-[#78350F] leading-relaxed">
            As informações disponíveis neste site têm finalidade <strong>educativa e informativa</strong>. Elas não substituem a consulta a um advogado ou à Defensoria Pública para casos específicos.
          </p>
        </div>
      </div>
    </div>
  );
}
