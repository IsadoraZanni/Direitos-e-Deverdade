import { useState } from 'react';
import { quizCategories, getCategoryById } from '../data/quiz';
import type { Page } from '../App';

interface QuizPageProps {
  stage: 'menu' | 'playing' | 'result';
  category?: string;
  question?: number;
  answers?: number[];
  score?: number;
  onNavigate: (page: Page) => void;
  onHome: () => void;
}

function CategoryCard({ icon, title, description, onClick }: { icon: string; title: string; description: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-white rounded-2xl border-2 border-[#D5DCE8] hover:border-[#1B3A6B] hover:shadow-xl shadow-md p-6 transition-all duration-200 group focus:outline-none focus:ring-2 focus:ring-[#1B3A6B]/30"
    >
      <div className="text-4xl mb-3">{icon}</div>
      <h3 className="font-display text-xl text-[#0F1C2E] mb-2 group-hover:text-[#1B3A6B] transition-colors duration-200">
        {title}
      </h3>
      <p className="text-sm text-[#6B7A8D] leading-relaxed">{description}</p>
      <div className="mt-4 flex items-center gap-1.5 text-xs font-semibold text-[#009C5B]">
        Iniciar quiz
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform duration-150">
          <path d="M3 8h10M9 4l4 4-4 4" />
        </svg>
      </div>
    </button>
  );
}

function QuizMenu({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-14 h-14 bg-[#1B3A6B] rounded-2xl mb-5">
          <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
            <circle cx="12" cy="12" r="10" />
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
            <path d="M12 17h.01" />
          </svg>
        </div>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-3">
          Teste seus conhecimentos
        </h1>
        <p className="text-[#6B7A8D] text-base max-w-lg mx-auto leading-relaxed">
          Escolha uma categoria e responda 4 perguntas de múltipla escolha sobre direitos e leis brasileiras. Ao final você verá sua pontuação!
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        {quizCategories.map((cat) => (
          <CategoryCard
            key={cat.id}
            icon={cat.icon}
            title={cat.title}
            description={cat.description}
            onClick={() => onNavigate({ type: 'quiz', stage: 'playing', category: cat.id, question: 0, answers: [] })}
          />
        ))}
      </div>
    </div>
  );
}

function QuizPlaying({ category, question = 0, answers = [], onNavigate, onHome }: {
  category: string;
  question: number;
  answers: number[];
  onNavigate: (page: Page) => void;
  onHome: () => void;
}) {
  const cat = getCategoryById(category);
  const [selected, setSelected] = useState<number | null>(null);
  const [confirmed, setConfirmed] = useState(false);

  if (!cat) return null;

  const q = cat.questions[question];
  const total = cat.questions.length;
  const progress = ((question) / total) * 100;

  const handleConfirm = () => {
    if (selected === null) return;
    setConfirmed(true);
  };

  const handleNext = () => {
    const newAnswers = [...answers, selected ?? -1];
    if (question + 1 >= total) {
      const score = newAnswers.filter((a, i) => a === cat.questions[i].correct).length;
      onNavigate({ type: 'quiz', stage: 'result', category, score, answers: newAnswers });
    } else {
      onNavigate({ type: 'quiz', stage: 'playing', category, question: question + 1, answers: newAnswers });
    }
  };

  const isCorrect = selected === q.correct;

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => onNavigate({ type: 'quiz', stage: 'menu' })}
          className="flex items-center gap-1.5 text-sm text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150"
        >
          <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
            <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
          Trocar categoria
        </button>
        <span className="text-sm font-semibold text-[#1B3A6B]">
          {cat.icon} {cat.title}
        </span>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-xs text-[#6B7A8D] mb-2">
          <span>Pergunta {question + 1} de {total}</span>
          <span>{Math.round(progress)}% concluído</span>
        </div>
        <div className="h-2 bg-[#EEF2FA] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#1B3A6B] rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Question card */}
      <div className="bg-white rounded-2xl border border-[#D5DCE8] shadow-md p-6 mb-5">
        <p className="font-display text-xl text-[#0F1C2E] leading-snug mb-6">
          {q.question}
        </p>

        {/* Options */}
        <div className="space-y-3">
          {q.options.map((option, i) => {
            let classes = 'w-full text-left px-4 py-3.5 rounded-xl border-2 text-sm font-medium transition-all duration-200 flex items-center gap-3 focus:outline-none ';

            if (!confirmed) {
              classes += selected === i
                ? 'border-[#1B3A6B] bg-[#EEF2FA] text-[#1B3A6B]'
                : 'border-[#D5DCE8] bg-white text-[#374151] hover:border-[#1B3A6B] hover:bg-[#EEF2FA]';
            } else {
              if (i === q.correct) {
                classes += 'border-[#009C5B] bg-[#ECFDF5] text-[#065F46]';
              } else if (i === selected && selected !== q.correct) {
                classes += 'border-[#DC2626] bg-[#FEF2F2] text-[#991B1B]';
              } else {
                classes += 'border-[#D5DCE8] bg-white text-[#9CA3AF]';
              }
            }

            return (
              <button
                key={i}
                className={classes}
                onClick={() => !confirmed && setSelected(i)}
                disabled={confirmed}
                aria-pressed={selected === i}
              >
                <span className={`flex-shrink-0 w-6 h-6 rounded-full border-2 text-xs font-bold flex items-center justify-center ${
                  confirmed && i === q.correct
                    ? 'border-[#009C5B] bg-[#009C5B] text-white'
                    : confirmed && i === selected && selected !== q.correct
                    ? 'border-[#DC2626] bg-[#DC2626] text-white'
                    : selected === i && !confirmed
                    ? 'border-[#1B3A6B] bg-[#1B3A6B] text-white'
                    : 'border-[#D5DCE8] text-[#9CA3AF]'
                }`}>
                  {String.fromCharCode(65 + i)}
                </span>
                {option}
                {confirmed && i === q.correct && (
                  <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 ml-auto text-[#009C5B]">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                )}
                {confirmed && i === selected && selected !== q.correct && (
                  <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 ml-auto text-[#DC2626]">
                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                )}
              </button>
            );
          })}
        </div>

        {/* Explanation */}
        {confirmed && (
          <div className={`mt-5 p-4 rounded-xl border ${isCorrect ? 'bg-[#ECFDF5] border-[#009C5B]/30' : 'bg-[#FEF2F2] border-[#DC2626]/30'}`}>
            <p className={`text-xs font-bold mb-1 ${isCorrect ? 'text-[#065F46]' : 'text-[#991B1B]'}`}>
              {isCorrect ? '✓ Resposta correta!' : '✗ Resposta incorreta'}
            </p>
            <p className={`text-sm leading-relaxed ${isCorrect ? 'text-[#065F46]' : 'text-[#7F1D1D]'}`}>
              {q.explanation}
            </p>
          </div>
        )}
      </div>

      {/* CTA */}
      {!confirmed ? (
        <button
          onClick={handleConfirm}
          disabled={selected === null}
          className="w-full py-3.5 rounded-xl bg-[#1B3A6B] text-white font-semibold text-sm hover:bg-[#254d8c] transition-colors duration-150 disabled:opacity-40 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-[#1B3A6B]/50"
        >
          Confirmar resposta
        </button>
      ) : (
        <button
          onClick={handleNext}
          className="w-full py-3.5 rounded-xl bg-[#009C5B] text-white font-semibold text-sm hover:bg-[#007a47] transition-colors duration-150 focus:outline-none"
        >
          {question + 1 >= total ? 'Ver resultado →' : 'Próxima pergunta →'}
        </button>
      )}
    </div>
  );
}

function QuizResult({ category, score = 0, answers = [], onNavigate, onHome }: {
  category: string;
  score: number;
  answers: number[];
  onNavigate: (page: Page) => void;
  onHome: () => void;
}) {
  const cat = getCategoryById(category);
  if (!cat) return null;
  const total = cat.questions.length;
  const pct = Math.round((score / total) * 100);

  let resultMsg = '';
  let resultColor = '';
  if (pct === 100) { resultMsg = 'Perfeito! Você é um especialista!'; resultColor = 'text-[#065F46]'; }
  else if (pct >= 75) { resultMsg = 'Muito bem! Você conhece bem seus direitos.'; resultColor = 'text-[#1B3A6B]'; }
  else if (pct >= 50) { resultMsg = 'Bom começo! Continue aprendendo.'; resultColor = 'text-[#B45309]'; }
  else { resultMsg = 'Continue estudando! Suas dúvidas são comuns.'; resultColor = 'text-[#991B1B]'; }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      {/* Score card */}
      <div className="bg-white rounded-2xl border border-[#D5DCE8] shadow-md p-8 mb-6 text-center">
        <div className="text-5xl mb-4">
          {pct === 100 ? '🏆' : pct >= 75 ? '🎉' : pct >= 50 ? '👍' : '📚'}
        </div>
        <h1 className="font-display text-3xl text-[#0F1C2E] mb-2">Resultado</h1>
        <p className={`font-semibold text-base mb-5 ${resultColor}`}>{resultMsg}</p>

        <div className="inline-flex items-center gap-3 bg-[#EEF2FA] px-8 py-4 rounded-2xl mb-4">
          <span className="font-display text-5xl text-[#1B3A6B]">{score}</span>
          <span className="text-[#6B7A8D] text-lg">/ {total}</span>
        </div>

        <div className="h-3 bg-[#EEF2FA] rounded-full overflow-hidden mx-auto max-w-xs mb-2">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${pct}%`,
              backgroundColor: pct >= 75 ? '#009C5B' : pct >= 50 ? '#F59E0B' : '#DC2626',
            }}
          />
        </div>
        <p className="text-sm text-[#6B7A8D]">{pct}% de acertos</p>
      </div>

      {/* Answer review */}
      <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6 mb-6">
        <h2 className="font-semibold text-[#1B3A6B] mb-4">Revisão das respostas</h2>
        <div className="space-y-3">
          {cat.questions.map((q, i) => {
            const isRight = answers[i] === q.correct;
            return (
              <div key={q.id} className={`p-3 rounded-xl border ${isRight ? 'bg-[#ECFDF5] border-[#009C5B]/30' : 'bg-[#FEF2F2] border-[#DC2626]/30'}`}>
                <div className="flex items-start gap-2">
                  <span className={`flex-shrink-0 text-sm font-bold ${isRight ? 'text-[#009C5B]' : 'text-[#DC2626]'}`}>
                    {isRight ? '✓' : '✗'}
                  </span>
                  <div>
                    <p className="text-sm text-[#0F1C2E] font-medium leading-snug mb-1">{q.question}</p>
                    {!isRight && answers[i] !== undefined && (
                      <p className="text-xs text-[#991B1B]">Você respondeu: {q.options[answers[i]]}</p>
                    )}
                    <p className="text-xs text-[#065F46] mt-0.5">✓ {q.options[q.correct]}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => onNavigate({ type: 'quiz', stage: 'playing', category, question: 0, answers: [] })}
          className="flex-1 py-3 rounded-xl border-2 border-[#1B3A6B] text-[#1B3A6B] font-semibold text-sm hover:bg-[#EEF2FA] transition-colors duration-150"
        >
          🔄 Refazer quiz
        </button>
        <button
          onClick={() => onNavigate({ type: 'quiz', stage: 'menu' })}
          className="flex-1 py-3 rounded-xl bg-[#009C5B] text-white font-semibold text-sm hover:bg-[#007a47] transition-colors duration-150"
        >
          Outras categorias
        </button>
        <button
          onClick={onHome}
          className="flex-1 py-3 rounded-xl bg-[#1B3A6B] text-white font-semibold text-sm hover:bg-[#254d8c] transition-colors duration-150"
        >
          Página inicial
        </button>
      </div>
    </div>
  );
}

export default function QuizPage({ stage, category, question, answers, score, onNavigate, onHome }: QuizPageProps) {
  if (stage === 'playing' && category) {
    return (
      <QuizPlaying
        category={category}
        question={question ?? 0}
        answers={answers ?? []}
        onNavigate={onNavigate}
        onHome={onHome}
      />
    );
  }

  if (stage === 'result' && category) {
    return (
      <QuizResult
        category={category}
        score={score ?? 0}
        answers={answers ?? []}
        onNavigate={onNavigate}
        onHome={onHome}
      />
    );
  }

  return <QuizMenu onNavigate={onNavigate} />;
}
