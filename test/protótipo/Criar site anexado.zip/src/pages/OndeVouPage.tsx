import { getOndeVouById } from '../data/content';
import BackButton from '../components/BackButton';

interface OndeVouPageProps {
  id: string;
  onBack: () => void;
  onHome: () => void;
}

export default function OndeVouPage({ id, onBack, onHome }: OndeVouPageProps) {
  const entry = getOndeVouById(id);

  if (!entry) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <p className="text-[#6B7A8D] mb-4">Conteúdo não encontrado.</p>
        <button onClick={onHome} className="text-[#1B3A6B] font-medium hover:underline">
          Voltar ao início
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      {/* Back */}
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button
          onClick={onHome}
          className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150"
        >
          Início
        </button>
      </div>

      {/* Header */}
      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#FEF3C7] text-[#92400E] mb-3">
          <span className="w-1.5 h-1.5 rounded-full bg-[#B45309]" />
          Onde buscar ajuda
        </span>
        <h1 className="font-display text-3xl md:text-4xl text-[#0F1C2E] leading-tight">
          {entry.title}
        </h1>
      </div>

      {/* Step 1 — Qual direito */}
      <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6 mb-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-full bg-[#1B3A6B] text-white text-sm font-bold flex items-center justify-center flex-shrink-0">
            1
          </div>
          <h2 className="font-semibold text-[#1B3A6B]">{entry.direitos.title}</h2>
        </div>
        <ul className="space-y-2">
          {entry.direitos.items.map((item, i) => (
            <li key={i} className="flex items-start gap-2.5">
              <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-[#1B3A6B] flex-shrink-0" />
              <span className="text-sm text-[#374151] leading-relaxed">{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Step 2 — Como identificar */}
      <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6 mb-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-full bg-[#1B3A6B] text-white text-sm font-bold flex items-center justify-center flex-shrink-0">
            2
          </div>
          <h2 className="font-semibold text-[#1B3A6B]">Como identificar a situação?</h2>
        </div>
        <p className="text-sm text-[#374151] mb-3">{entry.como_identificar.content}</p>
        <ul className="space-y-2">
          {entry.como_identificar.items.map((item, i) => (
            <li key={i} className="flex items-start gap-2.5 bg-[#F4F6F9] rounded-xl px-4 py-2.5">
              <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 text-[#009C5B] mt-0.5 flex-shrink-0">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              <span className="text-sm text-[#374151] leading-relaxed">{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Step 3 — O que fazer */}
      <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6 mb-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-full bg-[#1B3A6B] text-white text-sm font-bold flex items-center justify-center flex-shrink-0">
            3
          </div>
          <h2 className="font-semibold text-[#1B3A6B]">O que posso fazer?</h2>
        </div>
        <ol className="space-y-3">
          {entry.o_que_fazer.map((step, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="flex-shrink-0 w-6 h-6 rounded-full border-2 border-[#009C5B] text-[#009C5B] text-xs font-bold flex items-center justify-center">
                {i + 1}
              </span>
              <span className="text-sm text-[#374151] leading-relaxed pt-0.5">{step}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Step 4 — Onde procurar — HIGHLIGHTED */}
      <div className="bg-[#009C5B] rounded-2xl p-6 mb-4">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-8 h-8 rounded-full bg-white text-[#009C5B] text-sm font-bold flex items-center justify-center flex-shrink-0">
            4
          </div>
          <h2 className="font-semibold text-white text-lg">Onde procurar ajuda?</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {entry.onde_procurar.map((lugar, i) => (
            <div key={i} className="bg-white/15 backdrop-blur rounded-xl p-4 border border-white/20">
              <p className="font-semibold text-white text-sm mb-1">{lugar.name}</p>
              <p className="text-white/80 text-xs leading-relaxed mb-2">{lugar.descricao}</p>
              <p className="text-[#4ADEAA] text-xs font-medium">{lugar.contato}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Step 5 — Órgãos */}
      <div className="bg-white rounded-2xl border border-[#D5DCE8] p-6 mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-full bg-[#1B3A6B] text-white text-sm font-bold flex items-center justify-center flex-shrink-0">
            5
          </div>
          <h2 className="font-semibold text-[#1B3A6B]">Quais órgãos podem ser procurados?</h2>
        </div>
        <div className="space-y-3">
          {entry.orgaos.map((orgao, i) => (
            <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-[#F4F6F9]">
              <div className="flex-shrink-0">
                <span className="inline-block bg-[#EEF2FA] text-[#1B3A6B] text-xs font-semibold px-2 py-0.5 rounded-full">
                  {orgao.tipo}
                </span>
              </div>
              <div>
                <p className="text-sm font-semibold text-[#0F1C2E]">{orgao.name}</p>
                <p className="text-xs text-[#6B7A8D] mt-0.5">{orgao.descricao}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="flex gap-3">
        <button
          onClick={onBack}
          className="flex-1 py-3 rounded-xl border-2 border-[#D5DCE8] text-[#1B3A6B] font-semibold text-sm hover:border-[#1B3A6B] transition-colors duration-150"
        >
          ← Voltar
        </button>
        <button
          onClick={onHome}
          className="flex-1 py-3 rounded-xl bg-[#1B3A6B] text-white font-semibold text-sm hover:bg-[#254d8c] transition-colors duration-150"
        >
          Página inicial
        </button>
      </div>
    </div>
  );
}
