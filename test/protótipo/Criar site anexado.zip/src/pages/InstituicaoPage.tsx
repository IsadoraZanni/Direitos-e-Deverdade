import BackButton from '../components/BackButton';

interface InstituicaoPageProps {
  onBack: () => void;
  onHome: () => void;
}

export default function InstituicaoPage({ onBack, onHome }: InstituicaoPageProps) {
  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <BackButton onBack={onBack} />
        <button onClick={onHome} className="text-xs text-[#6B7A8D] hover:text-[#1B3A6B] transition-colors duration-150">Início</button>
      </div>

      <div className="mb-8">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#EEF2FA] text-[#1B3A6B] mb-3">
          Quem somos
        </span>
        <h1 className="font-display text-4xl text-[#0F1C2E] mb-3">Instituição</h1>
        <p className="text-[#6B7A8D] text-sm leading-relaxed">
          O Direitos DeVerdade é um projeto acadêmico desenvolvido no âmbito de uma instituição de ensino superior.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-[#D5DCE8] p-8 mb-5">
        {/* Logo placeholder */}
        <div className="w-20 h-20 bg-[#EEF2FA] border-2 border-dashed border-[#D5DCE8] rounded-2xl flex items-center justify-center mb-6 mx-auto">
          <span className="text-xs text-[#6B7A8D] text-center leading-tight px-2">Logo da Instituição</span>
        </div>

        <div className="text-center mb-6">
          <div className="h-5 bg-[#EEF2FA] rounded-lg w-64 mx-auto mb-2" />
          <div className="h-4 bg-[#F4F6F9] rounded-lg w-48 mx-auto" />
          <p className="text-xs text-[#9CA3AF] mt-2 italic">Nome da instituição a ser inserido</p>
        </div>

        <div className="space-y-4">
          <div className="bg-[#F4F6F9] rounded-xl p-4">
            <p className="text-xs font-semibold text-[#6B7A8D] uppercase tracking-wide mb-1">Instituição</p>
            <div className="h-4 bg-[#EEF2FA] rounded-lg w-3/4" />
          </div>
          <div className="bg-[#F4F6F9] rounded-xl p-4">
            <p className="text-xs font-semibold text-[#6B7A8D] uppercase tracking-wide mb-1">Curso</p>
            <div className="h-4 bg-[#EEF2FA] rounded-lg w-1/2" />
          </div>
          <div className="bg-[#F4F6F9] rounded-xl p-4">
            <p className="text-xs font-semibold text-[#6B7A8D] uppercase tracking-wide mb-1">Disciplina / Projeto</p>
            <div className="h-4 bg-[#EEF2FA] rounded-lg w-2/3" />
          </div>
          <div className="bg-[#F4F6F9] rounded-xl p-4">
            <p className="text-xs font-semibold text-[#6B7A8D] uppercase tracking-wide mb-1">Orientador(a)</p>
            <div className="h-4 bg-[#EEF2FA] rounded-lg w-1/2" />
          </div>
        </div>
      </div>

      <div className="bg-[#ECFDF5] border border-[#009C5B]/30 rounded-2xl p-5">
        <p className="text-sm text-[#065F46] leading-relaxed">
          Esta seção será preenchida com as informações da instituição de ensino vinculada ao projeto. O espaço está reservado para o logotipo, nome da instituição, curso, disciplina e orientador responsável.
        </p>
      </div>
    </div>
  );
}
