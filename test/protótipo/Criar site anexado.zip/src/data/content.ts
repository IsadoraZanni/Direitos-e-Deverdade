export interface ContentSection {
  title: string;
  content?: string;
  items?: string[];
  highlight?: boolean;
}

export interface ContentEntry {
  id: string;
  title: string;
  category: string;
  categoryId: 'direitos' | 'agentes' | 'leis';
  icon: string;
  summary: string;
  sections: ContentSection[];
}

export interface OndeVouEntry {
  id: string;
  title: string;
  icon: string;
  direitos: { title: string; items: string[] };
  como_identificar: { content: string; items: string[] };
  o_que_fazer: string[];
  onde_procurar: { name: string; descricao: string; contato: string }[];
  orgaos: { name: string; tipo: string; descricao: string }[];
}

export interface CardData {
  id: string;
  title: string;
  description: string;
  icon: string;
  categoryId: 'direitos' | 'agentes' | 'leis' | 'onde';
  minicards: { id: string; title: string; isOndeVou?: boolean }[];
}

export const cardsData: CardData[] = [
  {
    id: 'direitos',
    title: 'Direitos e Deveres',
    description: 'Conheça seus direitos e deveres como cidadão, trabalhador, consumidor e muito mais.',
    icon: 'scale',
    categoryId: 'direitos',
    minicards: [
      { id: 'cidadaos', title: 'Direitos e deveres dos cidadãos' },
      { id: 'trabalhadores', title: 'Direitos e deveres dos trabalhadores' },
      { id: 'consumidores', title: 'Direitos e deveres dos consumidores' },
      { id: 'estudantes', title: 'Direitos e deveres dos estudantes' },
      { id: 'idosos', title: 'Direitos e deveres dos idosos' },
      { id: 'criancas', title: 'Direitos e deveres das crianças e adolescentes' },
      { id: 'deficiencia', title: 'Direitos e deveres das pessoas com deficiência' },
    ],
  },
  {
    id: 'agentes',
    title: 'Funções de Agentes Públicos',
    description: 'Entenda quem faz o quê no governo: presidente, governador, prefeito, deputados e mais.',
    icon: 'building',
    categoryId: 'agentes',
    minicards: [
      { id: 'presidente', title: 'Funções do Presidente da República' },
      { id: 'governador', title: 'Funções do Governador' },
      { id: 'prefeito', title: 'Funções do Prefeito' },
      { id: 'deputado-federal', title: 'Funções do Deputado Federal' },
      { id: 'deputado-estadual', title: 'Funções do Deputado Estadual' },
      { id: 'senador', title: 'Funções do Senador' },
      { id: 'vereador', title: 'Funções do Vereador' },
    ],
  },
  {
    id: 'leis',
    title: 'Leis',
    description: 'Conheça as principais leis brasileiras em linguagem simples e acessível.',
    icon: 'book',
    categoryId: 'leis',
    minicards: [
      { id: 'constituicao-federal', title: 'Constituição Federal' },
      { id: 'codigo-civil', title: 'Código Civil' },
      { id: 'codigo-penal', title: 'Código Penal' },
      { id: 'cdc', title: 'Código de Defesa do Consumidor' },
      { id: 'eca', title: 'Estatuto da Criança e do Adolescente' },
      { id: 'estatuto-idoso', title: 'Estatuto do Idoso' },
      { id: 'lei-maria-penha', title: 'Lei Maria da Penha' },
      { id: 'lai', title: 'Lei de Acesso à Informação' },
      { id: 'lrf', title: 'Lei de Responsabilidade Fiscal' },
      { id: 'lia', title: 'Lei de Improbidade Administrativa' },
    ],
  },
  {
    id: 'onde',
    title: 'Onde vou se meu direito for ferido?',
    description: 'Saiba a quem recorrer quando seus direitos forem violados no trabalho, saúde, escola e mais.',
    icon: 'help',
    categoryId: 'onde',
    minicards: [
      { id: 'trabalho', title: 'Direitos violados no trabalho', isOndeVou: true },
      { id: 'escola', title: 'Direitos violados na escola', isOndeVou: true },
      { id: 'saude', title: 'Direitos violados na saúde', isOndeVou: true },
      { id: 'seguranca-publica', title: 'Direitos violados na segurança pública', isOndeVou: true },
      { id: 'moradia', title: 'Direitos violados na moradia', isOndeVou: true },
      { id: 'alimentacao', title: 'Direitos violados na alimentação', isOndeVou: true },
      { id: 'educacao', title: 'Direitos violados na educação', isOndeVou: true },
    ],
  },
];

export const contentEntries: ContentEntry[] = [
  // ===== DIREITOS =====
  {
    id: 'cidadaos',
    title: 'Direitos e Deveres dos Cidadãos',
    category: 'Direitos e Deveres',
    categoryId: 'direitos',
    icon: '🏳️',
    summary: 'Todo cidadão brasileiro possui direitos fundamentais garantidos pela Constituição Federal de 1988, assim como deveres que contribuem para o funcionamento da sociedade.',
    sections: [
      {
        title: 'Principais Direitos',
        items: [
          'Direito à vida e à segurança pessoal',
          'Direito à liberdade de expressão e de pensamento',
          'Direito à saúde — acesso ao SUS (Sistema Único de Saúde)',
          'Direito à educação pública e gratuita',
          'Direito à moradia digna',
          'Direito ao voto e à participação política',
          'Direito à igualdade perante a lei, sem discriminação',
          'Direito à privacidade e à inviolabilidade do domicílio',
          'Direito à ampla defesa em processos judiciais ou administrativos',
        ],
      },
      {
        title: 'Principais Deveres',
        items: [
          'Votar obrigatoriamente (entre 18 e 70 anos)',
          'Pagar impostos e contribuições legais',
          'Respeitar as leis brasileiras',
          'Preservar o patrimônio público',
          'Respeitar os direitos dos demais cidadãos',
          'Cuidar do meio ambiente',
          'Realizar o serviço militar (para homens, quando convocados)',
        ],
      },
      {
        title: 'Exemplos Práticos',
        content: 'Se você for preso, tem direito de saber o motivo, de ser comunicado de seus direitos e de ter acesso a um advogado (ou Defensor Público). Nenhuma autoridade pode prender alguém sem ordem judicial, exceto em flagrante delito. Toda pessoa tem direito de entrar com um habeas corpus para garantir a liberdade.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal de 1988, artigos 5º ao 17 — Título II: Dos Direitos e Garantias Fundamentais.',
      },
    ],
  },
  {
    id: 'trabalhadores',
    title: 'Direitos e Deveres dos Trabalhadores',
    category: 'Direitos e Deveres',
    categoryId: 'direitos',
    icon: '👷',
    summary: 'Os trabalhadores brasileiros com carteira assinada têm seus direitos garantidos pela Consolidação das Leis do Trabalho (CLT) e pela Constituição Federal.',
    sections: [
      {
        title: 'Principais Direitos do Trabalhador',
        items: [
          'Salário mínimo nacional (R$ 1.518 em 2025)',
          'Décimo terceiro salário (13º)',
          'Férias de 30 dias por ano com acréscimo de ⅓',
          'FGTS — Fundo de Garantia por Tempo de Serviço (8% do salário)',
          'Hora extra remunerada em no mínimo 50% a mais',
          'Licença maternidade de 120 dias e licença paternidade de 5 dias',
          'Repouso semanal remunerado (ao menos 1 dia por semana)',
          'Adicional noturno para trabalho entre 22h e 5h',
          'INSS — contribuição previdenciária para aposentadoria e benefícios',
          'Seguro-desemprego em caso de demissão sem justa causa',
        ],
      },
      {
        title: 'Principais Deveres do Trabalhador',
        items: [
          'Cumprir o horário de trabalho acordado',
          'Executar as tarefas com cuidado e responsabilidade',
          'Seguir as normas e regulamentos internos da empresa',
          'Zelar pelo patrimônio da empresa',
          'Manter conduta ética e respeitosa com colegas e superiores',
        ],
      },
      {
        title: 'Atenção: Trabalho Informal',
        content: 'Trabalhadores sem carteira assinada não têm os mesmos direitos garantidos automaticamente pela CLT. Se você trabalhar de forma não registrada, pode buscar o reconhecimento do vínculo empregatício na Justiça do Trabalho.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'CLT — Decreto-Lei 5.452/1943 e Constituição Federal de 1988, Art. 7º.',
      },
    ],
  },
  {
    id: 'consumidores',
    title: 'Direitos e Deveres dos Consumidores',
    category: 'Direitos e Deveres',
    categoryId: 'direitos',
    icon: '🛒',
    summary: 'O Código de Defesa do Consumidor (CDC) protege quem compra produtos ou contrata serviços no Brasil, garantindo informação clara, qualidade e reparação por danos.',
    sections: [
      {
        title: 'Principais Direitos do Consumidor',
        items: [
          'Direito à informação clara sobre o produto ou serviço',
          'Direito ao arrependimento: 7 dias para cancelar compras feitas fora do estabelecimento (online, telefone, catálogo)',
          'Garantia legal: 30 dias para produtos não duráveis; 90 dias para produtos duráveis',
          'Proteção contra publicidade enganosa e abusiva',
          'Direito à reparação por danos materiais e morais',
          'Direito a recusar produtos ou serviços não solicitados',
          'Acesso facilitado à justiça (pode abrir processo nos Juizados Especiais sem advogado até 20 salários mínimos)',
        ],
      },
      {
        title: 'Deveres do Consumidor',
        items: [
          'Pagar pelo produto ou serviço acordado',
          'Usar os produtos corretamente, seguindo as instruções',
          'Não danificar produtos intencionalmente para exigir troca',
          'Agir de boa-fé nas relações de consumo',
        ],
      },
      {
        title: 'Onde Reclamar',
        content: 'Procon do seu estado, plataforma consumidor.gov.br (mediação online gratuita) ou Juizado Especial Cível (JEC). Para produtos com risco à saúde, acione também a Anvisa.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Lei 8.078/1990 — Código de Defesa do Consumidor (CDC).',
      },
    ],
  },
  {
    id: 'estudantes',
    title: 'Direitos e Deveres dos Estudantes',
    category: 'Direitos e Deveres',
    categoryId: 'direitos',
    icon: '📚',
    summary: 'O estudante tem direito a uma educação de qualidade, tratamento digno e participação na vida escolar. A educação básica é obrigatória e gratuita na rede pública.',
    sections: [
      {
        title: 'Principais Direitos dos Estudantes',
        items: [
          'Educação pública e gratuita no ensino fundamental e médio',
          'Tratamento respeitoso por professores, funcionários e colegas',
          'Acesso a informações sobre o regimento e normas da escola',
          'Participar do grêmio estudantil e de processos de decisão escolar',
          'Não ser punido de forma arbitrária ou humilhante',
          'Recorrer de notas e decisões disciplinares',
          'Meio-período escolar (turno integral está em expansão pelo MEC)',
          'Estudantes universitários: meia-entrada em eventos culturais',
        ],
      },
      {
        title: 'Deveres dos Estudantes',
        items: [
          'Frequentar as aulas regularmente (frequência mínima de 75%)',
          'Respeitar professores, funcionários e colegas',
          'Cumprir o regimento escolar',
          'Realizar as atividades propostas',
          'Preservar o patrimônio da escola',
        ],
      },
      {
        title: 'Bullying e Cyberbullying',
        content: 'A Lei 13.185/2015 instituiu o Programa de Combate à Intimidação Sistemática. Se você sofrer bullying, fale com um adulto de confiança, registre os episódios e comunique à direção. Se necessário, procure o Conselho Tutelar ou a Delegacia.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal, Art. 206; Lei de Diretrizes e Bases da Educação (LDB) — Lei 9.394/1996; Lei 13.185/2015 (Antibullying).',
      },
    ],
  },
  {
    id: 'idosos',
    title: 'Direitos e Deveres dos Idosos',
    category: 'Direitos e Deveres',
    categoryId: 'direitos',
    icon: '🧓',
    summary: 'O Estatuto do Idoso garante proteção especial a brasileiros com 60 anos ou mais, assegurando prioridade nos serviços públicos, saúde e proteção contra discriminação.',
    sections: [
      {
        title: 'Principais Direitos dos Idosos',
        items: [
          'Atendimento prioritário em bancos, hospitais, repartições públicas e outros serviços',
          'Gratuidade nos transportes coletivos para maiores de 65 anos',
          'Desconto de 50% em atividades culturais, de lazer e esportivas (shows, museus, cinemas)',
          'Acesso prioritário e gratuito ao SUS, incluindo medicamentos e próteses',
          'Proteção contra qualquer forma de negligência, discriminação, violência e abandono',
          'Benefício de Prestação Continuada (BPC/LOAS): 1 salário mínimo para idosos com baixa renda',
          'Vagas reservadas no transporte coletivo e em filas de atendimento',
        ],
      },
      {
        title: 'Deveres dos Idosos',
        items: [
          'Respeitar as leis e as demais pessoas',
          'Contribuir com a experiência e sabedoria para a família e comunidade',
          'Cuidar da própria saúde na medida do possível',
        ],
      },
      {
        title: 'Violência contra o Idoso',
        content: 'Qualquer tipo de violência contra idoso (física, psicológica, financeira, sexual ou abandono) é crime. Denuncie: ligue 180 (Central de Atendimento à Mulher), 100 (Direitos Humanos) ou procure a Delegacia do Idoso ou o Ministério Público.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Lei 10.741/2003 — Estatuto do Idoso; Constituição Federal, Art. 230.',
      },
    ],
  },
  {
    id: 'criancas',
    title: 'Direitos e Deveres das Crianças e Adolescentes',
    category: 'Direitos e Deveres',
    categoryId: 'direitos',
    icon: '👦',
    summary: 'O ECA (Estatuto da Criança e do Adolescente) garante proteção integral a crianças (até 12 anos) e adolescentes (12 a 18 anos), priorizando seu desenvolvimento saudável.',
    sections: [
      {
        title: 'Principais Direitos',
        items: [
          'Vida, saúde, alimentação, educação e lazer',
          'Cultura, dignidade, respeito e liberdade',
          'Convivência familiar e comunitária',
          'Proteção contra toda forma de negligência, discriminação, exploração e violência',
          'Proibição do trabalho antes dos 16 anos (exceto aprendiz a partir dos 14)',
          'Medidas socioeducativas em vez de prisão para adolescentes infratores',
          'Acesso prioritário e gratuito ao SUS',
        ],
      },
      {
        title: 'Deveres',
        items: [
          'Respeitar os pais, responsáveis, professores e demais adultos',
          'Frequentar a escola regularmente',
          'Respeitar as leis e os direitos dos outros',
          'Colaborar com a família e a comunidade',
        ],
      },
      {
        title: 'Conselho Tutelar',
        content: 'O Conselho Tutelar é o órgão responsável por zelar pelos direitos das crianças e adolescentes. Se houver violação de direitos — como abandono, maus-tratos ou exploração —, qualquer cidadão pode e deve denunciar ao Conselho Tutelar do município ou pelo Disque 100.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Lei 8.069/1990 — Estatuto da Criança e do Adolescente (ECA); Constituição Federal, Art. 227.',
      },
    ],
  },
  {
    id: 'deficiencia',
    title: 'Direitos e Deveres das Pessoas com Deficiência',
    category: 'Direitos e Deveres',
    categoryId: 'direitos',
    icon: '♿',
    summary: 'A Lei Brasileira de Inclusão garante acessibilidade, inclusão e igualdade de oportunidades para pessoas com deficiência física, intelectual, visual, auditiva ou psicossocial.',
    sections: [
      {
        title: 'Principais Direitos',
        items: [
          'Acessibilidade em espaços públicos, transportes e edificações',
          'Reserva de 5% das vagas em concursos públicos',
          'Cotas em empresas privadas com mais de 100 funcionários (2% a 5% das vagas)',
          'Benefício de Prestação Continuada (BPC/LOAS): 1 salário mínimo para pessoas com deficiência em situação de pobreza',
          'Gratuidade ou desconto em transportes públicos',
          'Atendimento prioritário em filas e serviços',
          'Isenção de IPI na compra de automóveis adaptados',
          'Direito à saúde, reabilitação, educação inclusiva e tecnologia assistiva',
        ],
      },
      {
        title: 'Educação Inclusiva',
        content: 'Escolas públicas e privadas são obrigadas a aceitar estudantes com deficiência e oferecer suporte adequado. A recusa é ilegal e pode ser denunciada ao Ministério Público.',
        highlight: true,
      },
      {
        title: 'Deveres',
        items: [
          'Respeitar as leis e os direitos dos demais cidadãos',
          'Utilizar os espaços e benefícios de forma responsável',
        ],
      },
      {
        title: 'Base Legal',
        content: 'Lei 13.146/2015 — Lei Brasileira de Inclusão (Estatuto da Pessoa com Deficiência); Constituição Federal, Art. 7º, XXXI e Art. 37, VIII.',
      },
    ],
  },

  // ===== AGENTES PÚBLICOS =====
  {
    id: 'presidente',
    title: 'Funções do Presidente da República',
    category: 'Funções de Agentes Públicos',
    categoryId: 'agentes',
    icon: '🇧🇷',
    summary: 'O Presidente da República é o chefe do Poder Executivo Federal e o representante máximo do Estado brasileiro, eleito diretamente pelo povo por mandato de 4 anos.',
    sections: [
      {
        title: 'Principais Funções',
        items: [
          'Chefiar o governo federal e a administração pública',
          'Sancionar (aprovar) ou vetar leis aprovadas pelo Congresso Nacional',
          'Propor ao Congresso o Orçamento Anual (LOA) e o Plano Plurianual (PPA)',
          'Nomear e exonerar ministros de Estado e outros cargos',
          'Comandar as Forças Armadas (Exército, Marinha e Aeronáutica)',
          'Representar o Brasil nas relações internacionais',
          'Celebrar tratados e acordos internacionais (sujeitos à aprovação do Congresso)',
          'Decretar estado de defesa e estado de sítio (com autorização do Congresso)',
          'Editar Medidas Provisórias com força de lei (por prazo determinado)',
        ],
      },
      {
        title: 'Mandato e Reeleição',
        content: 'O mandato presidencial é de 4 anos. É permitida apenas 1 reeleição consecutiva. O vice-presidente assume em caso de ausência ou impedimento.',
        highlight: true,
      },
      {
        title: 'Responsabilização',
        content: 'O Presidente pode ser afastado por impeachment, aprovado pela Câmara dos Deputados e julgado pelo Senado. Também pode responder por crimes comuns no Supremo Tribunal Federal (STF).',
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal de 1988, Arts. 76 a 91 — Capítulo II: Do Poder Executivo.',
      },
    ],
  },
  {
    id: 'governador',
    title: 'Funções do Governador',
    category: 'Funções de Agentes Públicos',
    categoryId: 'agentes',
    icon: '🗺️',
    summary: 'O Governador é o chefe do Poder Executivo estadual, eleito diretamente pelo povo por mandato de 4 anos, podendo ser reeleito uma vez.',
    sections: [
      {
        title: 'Principais Funções',
        items: [
          'Administrar o estado e gerir os serviços públicos estaduais',
          'Propor o orçamento estadual e enviá-lo à Assembleia Legislativa',
          'Sancionar ou vetar projetos de lei aprovados pela Assembleia',
          'Nomear e exonerar secretários de Estado',
          'Coordenar a Polícia Civil e Militar estadual (segurança pública)',
          'Representar o estado nas relações com o governo federal e outros estados',
          'Decretar intervenção em municípios, nos casos previstos em lei',
          'Administrar bens públicos estaduais',
        ],
      },
      {
        title: 'Diferença entre Governador e Prefeito',
        content: 'O Governador atua em âmbito estadual (educação e saúde de média/alta complexidade, segurança pública, justiça estadual). O Prefeito cuida do município (saúde básica, educação infantil, limpeza urbana, transporte local).',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal, Arts. 25 a 28; Constituições estaduais de cada unidade federativa.',
      },
    ],
  },
  {
    id: 'prefeito',
    title: 'Funções do Prefeito',
    category: 'Funções de Agentes Públicos',
    categoryId: 'agentes',
    icon: '🏙️',
    summary: 'O Prefeito é o chefe do Poder Executivo municipal, eleito diretamente pelo povo por mandato de 4 anos, responsável por administrar a cidade e os serviços locais.',
    sections: [
      {
        title: 'Principais Funções',
        items: [
          'Administrar o município e os serviços públicos locais',
          'Propor o orçamento municipal à Câmara dos Vereadores',
          'Assinar contratos e convênios em nome do município',
          'Gerenciar a saúde básica (UBSs, postos de saúde)',
          'Administrar as escolas municipais (educação infantil e fundamental)',
          'Coordenar a limpeza urbana, coleta de lixo e iluminação pública',
          'Cuidar do transporte público municipal',
          'Emitir alvarás e licenças para funcionamento de estabelecimentos',
          'Promover obras e infraestrutura no município',
        ],
      },
      {
        title: 'Responsabilidade Fiscal',
        content: 'O Prefeito deve cumprir a Lei de Responsabilidade Fiscal (LRF) e não pode criar despesas sem previsão de receita. O descumprimento pode gerar crime de improbidade administrativa.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal, Arts. 29 e 30; Lei Orgânica de cada município.',
      },
    ],
  },
  {
    id: 'deputado-federal',
    title: 'Funções do Deputado Federal',
    category: 'Funções de Agentes Públicos',
    categoryId: 'agentes',
    icon: '🏛️',
    summary: 'O Deputado Federal integra a Câmara dos Deputados, uma das duas casas do Congresso Nacional. São eleitos por estado, com mandato de 4 anos.',
    sections: [
      {
        title: 'Principais Funções',
        items: [
          'Propor, debater e votar projetos de lei federais',
          'Aprovar o Orçamento Anual da União (LOA)',
          'Fiscalizar o Poder Executivo e o uso dos recursos públicos',
          'Autorizar o impeachment do Presidente (com 2/3 dos votos)',
          'Aprovar Medidas Provisórias enviadas pelo Presidente',
          'Criar Comissões Parlamentares de Inquérito (CPIs)',
          'Votar emendas à Constituição Federal (com 3/5 dos votos em dois turnos)',
        ],
      },
      {
        title: 'Quantos deputados existem?',
        content: 'A Câmara dos Deputados tem 513 deputados federais. O número por estado é proporcional à população, com mínimo de 8 e máximo de 70 por estado.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal de 1988, Arts. 44 a 56 — Câmara dos Deputados.',
      },
    ],
  },
  {
    id: 'deputado-estadual',
    title: 'Funções do Deputado Estadual',
    category: 'Funções de Agentes Públicos',
    categoryId: 'agentes',
    icon: '🗳️',
    summary: 'O Deputado Estadual integra a Assembleia Legislativa do Estado. Legisla em âmbito estadual e fiscaliza o Poder Executivo do estado.',
    sections: [
      {
        title: 'Principais Funções',
        items: [
          'Criar leis estaduais (válidas apenas dentro do estado)',
          'Aprovar o orçamento estadual',
          'Fiscalizar o Governador e o uso dos recursos do estado',
          'Autorizar o afastamento ou cassação do Governador',
          'Criar Comissões Parlamentares de Inquérito (CPIs) estaduais',
          'Votar emendas à Constituição Estadual',
        ],
      },
      {
        title: 'Diferença entre Deputado Estadual e Federal',
        content: 'O Deputado Federal cria leis que valem em todo o Brasil. O Deputado Estadual cria leis que valem apenas dentro do estado. Ambos têm mandato de 4 anos, mas atuam em esferas diferentes.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal de 1988, Arts. 27 e 28; Constituição estadual de cada estado.',
      },
    ],
  },
  {
    id: 'senador',
    title: 'Funções do Senador',
    category: 'Funções de Agentes Públicos',
    categoryId: 'agentes',
    icon: '⭐',
    summary: 'O Senador representa seu estado no Senado Federal, a câmara alta do Congresso Nacional. Cada estado tem exatamente 3 senadores, com mandato de 8 anos.',
    sections: [
      {
        title: 'Principais Funções',
        items: [
          'Aprovar leis federais (após votação na Câmara dos Deputados)',
          'Aprovar tratados e acordos internacionais',
          'Julgar autoridades em crimes de responsabilidade (com o STF)',
          'Autorizar empréstimos dos estados e municípios',
          'Aprovar indicações do Presidente para cargos no STF, TCU e outros',
          'Fiscalizar o Poder Executivo federal',
          'Propor emendas à Constituição Federal',
        ],
      },
      {
        title: 'Representação Igualitária dos Estados',
        content: 'Diferente da Câmara (proporcional à população), o Senado dá representação igualitária: todos os 27 estados (e o DF) têm 3 senadores. Isso garante que estados menores tenham voz equivalente. Total: 81 senadores.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal de 1988, Arts. 44 a 52 — Senado Federal.',
      },
    ],
  },
  {
    id: 'vereador',
    title: 'Funções do Vereador',
    category: 'Funções de Agentes Públicos',
    categoryId: 'agentes',
    icon: '🏘️',
    summary: 'O Vereador integra a Câmara Municipal, o Poder Legislativo do município. É o representante do povo mais próximo da realidade local, com mandato de 4 anos.',
    sections: [
      {
        title: 'Principais Funções',
        items: [
          'Criar, aprovar e revogar leis municipais (válidas apenas no município)',
          'Aprovar o orçamento municipal (LOA)',
          'Fiscalizar o Prefeito e a Câmara Municipal',
          'Cassar o mandato do Prefeito, se necessário',
          'Propor melhorias para o município (ruas, praças, serviços)',
          'Receber e encaminhar demandas da população',
          'Criar Comissões de Investigação municipais',
        ],
      },
      {
        title: 'O Vereador mais próximo do cidadão',
        content: 'O Vereador é o representante político mais acessível ao cidadão comum. Você pode visitar a Câmara Municipal, assistir às sessões (são públicas) e falar com seu vereador sobre problemas do bairro.',
        highlight: true,
      },
      {
        title: 'Base Legal',
        content: 'Constituição Federal, Art. 29; Lei Orgânica de cada município.',
      },
    ],
  },

  // ===== LEIS =====
  {
    id: 'constituicao-federal',
    title: 'Constituição Federal de 1988',
    category: 'Leis',
    categoryId: 'leis',
    icon: '📜',
    summary: 'A Constituição Federal é a lei máxima do Brasil, chamada de "Constituição Cidadã". Promulgada em 5 de outubro de 1988, estabelece os direitos fundamentais e organiza o Estado brasileiro.',
    sections: [
      {
        title: 'O que é a Constituição Federal?',
        content: 'É o conjunto de normas mais importantes do país. Todas as outras leis devem estar de acordo com ela. Se uma lei contradiz a Constituição, ela é considerada inconstitucional e pode ser anulada pelo Supremo Tribunal Federal (STF).',
      },
      {
        title: 'Principais Direitos Garantidos (Art. 5º)',
        items: [
          'Direito à vida, liberdade, igualdade, segurança e propriedade',
          'Proibição de tortura e tratamento degradante',
          'Liberdade de expressão, de pensamento e de consciência',
          'Inviolabilidade do domicílio e das comunicações',
          'Direito ao contraditório e à ampla defesa',
          'Ninguém pode ser preso sem flagrante ou ordem judicial',
          'Habeas corpus: proteção contra prisão ilegal',
          'Mandado de segurança: proteção de direito líquido e certo',
        ],
      },
      {
        title: 'Direitos Sociais',
        items: [
          'Educação pública e gratuita',
          'Saúde (SUS)',
          'Moradia e alimentação',
          'Trabalho e seguridade social',
          'Lazer e segurança',
          'Proteção à maternidade e infância',
        ],
      },
      {
        title: 'Organização do Estado',
        content: 'A Constituição divide o poder em três: Executivo (governa), Legislativo (faz leis) e Judiciário (julga). Nenhum dos três pode se sobrepor ao outro — é o sistema de freios e contrapesos.',
        highlight: true,
      },
      {
        title: 'Dados Importantes',
        items: [
          '250 artigos permanentes + Atos das Disposições Constitucionais Transitórias (ADCT)',
          'Promulgada em 5 de outubro de 1988, após o fim da ditadura militar',
          'Já recebeu mais de 100 emendas constitucionais',
          'Pode ser consultada gratuitamente no site do Senado Federal',
        ],
      },
    ],
  },
  {
    id: 'codigo-civil',
    title: 'Código Civil',
    category: 'Leis',
    categoryId: 'leis',
    icon: '📋',
    summary: 'O Código Civil regula as relações entre pessoas físicas e jurídicas (privadas) no Brasil. Cobre temas como casamento, contratos, herança, responsabilidade civil e propriedade.',
    sections: [
      {
        title: 'O que regula o Código Civil?',
        content: 'Enquanto a Constituição Federal define os direitos fundamentais, o Código Civil detalha como as relações entre pessoas (e empresas) devem funcionar na prática — casamentos, divórcios, contratos de aluguel, heranças, etc.',
      },
      {
        title: 'Principais Temas',
        items: [
          'Personalidade jurídica: quem pode ter direitos e obrigações',
          'Família: casamento, divórcio, adoção, poder familiar',
          'Contratos: compra e venda, aluguel, prestação de serviço, empréstimos',
          'Herança e sucessão: o que acontece com os bens após a morte',
          'Responsabilidade civil: quem causa dano deve reparar (indenização)',
          'Propriedade e posse de bens imóveis',
          'Direitos reais: hipoteca, penhor, usufruto',
        ],
      },
      {
        title: 'Maioridade Civil',
        content: 'O Código Civil estabelece que a maioridade civil é aos 18 anos. A partir daí, a pessoa pode praticar todos os atos da vida civil sem assistência de um responsável. Entre 16 e 18 anos, o jovem é relativamente incapaz e precisa de autorização dos pais ou responsáveis para certos atos.',
        highlight: true,
      },
      {
        title: 'Dados da Lei',
        content: 'Lei 10.406/2002, com 2.046 artigos. Entrou em vigor em 2003, substituindo o Código Civil de 1916.',
      },
    ],
  },
  {
    id: 'codigo-penal',
    title: 'Código Penal',
    category: 'Leis',
    categoryId: 'leis',
    icon: '⚖️',
    summary: 'O Código Penal define quais condutas são consideradas crimes no Brasil e quais penas cabem a cada um. Ninguém pode ser punido por algo que não esteja previsto em lei.',
    sections: [
      {
        title: 'O que é o Código Penal?',
        content: 'É a lei que lista os crimes e as respectivas punições. O princípio básico é: "não há crime sem lei anterior que o defina, nem pena sem prévia cominação legal" (princípio da legalidade). Isso protege o cidadão contra punições arbitrárias.',
      },
      {
        title: 'Estrutura do Código Penal',
        items: [
          'Parte Geral: princípios, tipos de pena, circunstâncias agravantes/atenuantes, extinção da punibilidade',
          'Parte Especial: crimes contra a pessoa, patrimônio, dignidade sexual, família, administração pública, etc.',
        ],
      },
      {
        title: 'Tipos de Penas',
        items: [
          'Privativas de liberdade: reclusão (crimes mais graves) e detenção (crimes menos graves)',
          'Restritivas de direitos: prestação de serviços à comunidade, proibição de atividades, etc.',
          'Multa: pagamento de valor em dinheiro ao fundo penitenciário',
        ],
      },
      {
        title: 'Crimes Comuns e Penas',
        items: [
          'Furto: até 4 anos de reclusão',
          'Roubo: 4 a 10 anos de reclusão',
          'Homicídio simples: 6 a 20 anos de reclusão',
          'Tráfico de drogas: 5 a 15 anos de reclusão (Lei 11.343/2006)',
          'Estelionato (golpe): 1 a 5 anos de reclusão',
        ],
      },
      {
        title: 'Imputabilidade Penal',
        content: 'No Brasil, a responsabilidade penal começa aos 18 anos. Menores de 18 anos respondem pelo ECA (Estatuto da Criança e do Adolescente) e recebem medidas socioeducativas, não penas de prisão.',
        highlight: true,
      },
      {
        title: 'Dados da Lei',
        content: 'Decreto-Lei 2.848/1940, com diversas atualizações ao longo dos anos. Disponível no site da Câmara dos Deputados.',
      },
    ],
  },
  {
    id: 'cdc',
    title: 'Código de Defesa do Consumidor',
    category: 'Leis',
    categoryId: 'leis',
    icon: '🛡️',
    summary: 'O CDC protege o consumidor nas relações de compra e venda de produtos e serviços, reconhecendo que o consumidor é a parte mais vulnerável na relação de consumo.',
    sections: [
      {
        title: 'Principais Proteções do CDC',
        items: [
          'Direito à informação clara, adequada e verdadeira sobre produtos e serviços',
          'Proteção contra publicidade enganosa e abusiva',
          'Direito de arrependimento: 7 dias corridos para desistir de compras fora do estabelecimento (online, telefone, catálogo)',
          'Proibição de práticas abusivas (venda casada, preço diferente do anunciado, etc.)',
          'Inversão do ônus da prova: o fornecedor deve provar que não errou',
          'Responsabilidade pelo produto: o fabricante responde por danos causados pelo produto',
        ],
      },
      {
        title: 'Prazos de Garantia',
        items: [
          'Produtos NÃO duráveis (alimentos, cosméticos): 30 dias',
          'Produtos DURÁVEIS (eletrodomésticos, eletrônicos, veículos): 90 dias',
          'A garantia conta a partir da entrega do produto ou término do serviço',
          'A garantia contratual (do fabricante) é adicional, não substitui a legal',
        ],
        highlight: true,
      },
      {
        title: 'Como Exercer Seus Direitos',
        items: [
          'Guarde sempre notas fiscais e comprovantes de compra',
          'Registre reclamações no Procon do seu estado',
          'Use a plataforma consumidor.gov.br (gratuita)',
          'Procure o Juizado Especial Cível (JEC) para causas até 40 salários mínimos',
        ],
      },
      {
        title: 'Dados da Lei',
        content: 'Lei 8.078/1990. Uma das mais importantes proteções ao cidadão brasileiro.',
      },
    ],
  },
  {
    id: 'eca',
    title: 'Estatuto da Criança e do Adolescente (ECA)',
    category: 'Leis',
    categoryId: 'leis',
    icon: '👶',
    summary: 'O ECA garante proteção integral e prioritária a crianças (até 12 anos) e adolescentes (12 a 18 anos), abrangendo saúde, educação, família, convivência social e medidas protetivas.',
    sections: [
      {
        title: 'Doutrina da Proteção Integral',
        content: 'O ECA adota a ideia de que crianças e adolescentes não são objetos de intervenção, mas sujeitos de direitos. Sua proteção é prioridade absoluta — deve vir antes de qualquer outra demanda da sociedade ou do Estado.',
      },
      {
        title: 'Principais Direitos Garantidos',
        items: [
          'Vida, saúde, alimentação, educação, lazer e cultura',
          'Dignidade, respeito, liberdade e convivência familiar e comunitária',
          'Proteção contra toda forma de negligência, discriminação e exploração',
          'Acesso gratuito ao SUS com atendimento prioritário',
          'Educação pública e gratuita',
          'Direito à identidade — todo bebê deve ter registro de nascimento gratuito',
        ],
      },
      {
        title: 'Proibição de Trabalho Infantil',
        items: [
          'Proibido qualquer trabalho antes dos 16 anos',
          'Trabalho como aprendiz é permitido a partir dos 14 anos',
          'Menores de 18 anos não podem trabalhar à noite, em locais perigosos ou insalubres',
        ],
        highlight: true,
      },
      {
        title: 'Medidas Socioeducativas',
        content: 'Adolescentes de 12 a 18 anos que cometem atos infracionais não vão para a prisão. Recebem medidas socioeducativas: advertência, obrigação de reparar dano, prestação de serviço à comunidade, liberdade assistida ou internação (em último caso).',
      },
      {
        title: 'Dados da Lei',
        content: 'Lei 8.069/1990. Para denúncias de violação, ligue Disque 100 (gratuito, 24h).',
      },
    ],
  },
  {
    id: 'estatuto-idoso',
    title: 'Estatuto do Idoso',
    category: 'Leis',
    categoryId: 'leis',
    icon: '🤝',
    summary: 'O Estatuto do Idoso regula os direitos das pessoas com 60 anos ou mais, assegurando prioridade nos serviços, proteção à saúde, dignidade e combate à violência.',
    sections: [
      {
        title: 'Quem é Considerado Idoso?',
        content: 'No Brasil, o Estatuto do Idoso considera idosa a pessoa com 60 anos ou mais. A Organização Mundial da Saúde (OMS) usa 65 anos para países desenvolvidos, mas o Brasil adota 60 anos por lei.',
      },
      {
        title: 'Principais Direitos',
        items: [
          'Atendimento preferencial em bancos, hospitais, repartições e serviços',
          'Gratuidade no transporte coletivo intermunicipal para maiores de 65 anos',
          '50% de desconto em atividades de cultura, lazer e esporte',
          'Prioridade no SUS, incluindo medicamentos, próteses e órteses',
          'Benefício de Prestação Continuada (BPC): 1 salário mínimo para idosos com renda familiar de até ¼ do salário mínimo per capita',
          'Proteção especial contra abandono, maus-tratos e discriminação',
          'Direito à habitação digna — prioridade em programas habitacionais',
        ],
      },
      {
        title: 'Crimes Contra o Idoso',
        content: 'Discriminar idoso, abandoná-lo, expô-lo a risco, apropriar-se de seus bens sem consentimento ou retardar pagamentos previdenciários são crimes previstos no próprio Estatuto, com penas de 6 meses a 12 anos de prisão conforme a gravidade.',
        highlight: true,
      },
      {
        title: 'Dados da Lei',
        content: 'Lei 10.741/2003. Para denúncias, ligue para o Disque 100 (gratuito) ou procure o Ministério Público.',
      },
    ],
  },
  {
    id: 'lei-maria-penha',
    title: 'Lei Maria da Penha',
    category: 'Leis',
    categoryId: 'leis',
    icon: '🌸',
    summary: 'A Lei Maria da Penha cria mecanismos para prevenir e punir a violência doméstica e familiar contra a mulher. É considerada uma das melhores leis do mundo na proteção à mulher.',
    sections: [
      {
        title: 'O que é a Violência Doméstica?',
        content: 'A lei protege mulheres contra qualquer violência praticada por familiar, companheiro (atual ou ex), com quem conviva ou tenha convivido, independentemente do gênero do agressor.',
      },
      {
        title: 'Tipos de Violência Previstos na Lei',
        items: [
          'Física: qualquer agressão corporal',
          'Psicológica: humilhação, ameaça, controle, isolamento',
          'Sexual: qualquer ato sexual sem consentimento',
          'Patrimonial: roubar, destruir ou controlar bens e documentos da mulher',
          'Moral: difamar, caluniar ou injuriar a mulher',
        ],
      },
      {
        title: 'Medidas Protetivas',
        content: 'A mulher pode pedir medidas protetivas de urgência ao juiz, como o afastamento do agressor do lar, proibição de se aproximar, suspensão da posse de armas. O juiz deve decidir em 48 horas.',
        highlight: true,
      },
      {
        title: 'Onde Buscar Ajuda',
        items: [
          'Central de Atendimento à Mulher: ligue 180 (gratuito, 24h)',
          'Delegacia da Mulher (DEAM) ou qualquer delegacia',
          'Casa de Acolhimento para mulheres em risco',
          'Ministério Público',
          'Defensoria Pública',
        ],
      },
      {
        title: 'Dados da Lei',
        content: 'Lei 11.340/2006. O nome é homenagem a Maria da Penha Maia Fernandes, que ficou paraplégica após agressões do marido e lutou por 20 anos para que ele fosse condenado.',
      },
    ],
  },
  {
    id: 'lai',
    title: 'Lei de Acesso à Informação (LAI)',
    category: 'Leis',
    categoryId: 'leis',
    icon: '🔍',
    summary: 'A LAI garante que qualquer pessoa pode pedir informações a órgãos públicos, que devem responder dentro do prazo legal. Transparência é a regra; o sigilo é exceção.',
    sections: [
      {
        title: 'O que garante a LAI?',
        content: 'Qualquer cidadão brasileiro — ou estrangeiro — pode solicitar informações a órgãos públicos (prefeituras, estados, ministérios, empresas públicas) sem precisar explicar o motivo do pedido.',
      },
      {
        title: 'Como Funciona',
        items: [
          'O pedido pode ser feito pessoalmente, por carta ou online no Portal Fala.BR (falabr.cgu.gov.br)',
          'O órgão tem 20 dias para responder (prorrogáveis por mais 10 dias)',
          'Se houver recurso, o prazo para decisão é de 5 dias',
          'Em caso de descumprimento, o cidadão pode recorrer à CGU (Controladoria-Geral da União) ou ao Ministério Público',
        ],
      },
      {
        title: 'O que pode ser negado?',
        content: 'Informações classificadas como sigilosas (segurança nacional, privacidade de terceiros) podem ser negadas. Mas a justificativa deve ser apresentada e pode ser questionada.',
        highlight: true,
      },
      {
        title: 'Dados da Lei',
        content: 'Lei 12.527/2011. Vigente desde maio de 2012. Portais de transparência dos governos são obrigatórios por ela.',
      },
    ],
  },
  {
    id: 'lrf',
    title: 'Lei de Responsabilidade Fiscal (LRF)',
    category: 'Leis',
    categoryId: 'leis',
    icon: '💰',
    summary: 'A LRF estabelece normas de finanças públicas para uma gestão fiscal responsável, proibindo gastos sem fonte de receita e limitando despesas com pessoal.',
    sections: [
      {
        title: 'Para que serve a LRF?',
        content: 'Antes da LRF, era comum gestores públicos gastarem mais do que arrecadavam e deixarem dívidas para o próximo governo. A lei criou limites e obrigações de transparência para evitar esse comportamento.',
      },
      {
        title: 'Principais Regras',
        items: [
          'Limites de gastos com pessoal: municípios (60% da receita), estados e União (50%)',
          'Proibição de criar despesas sem prever a fonte de receita',
          'Proibição de contrair novas dívidas se as anteriores não forem pagas',
          'Publicação trimestral de relatórios de execução orçamentária',
          'No último ano do mandato: proibido contratar dívidas sem receita ou fazer aumentos salariais',
        ],
      },
      {
        title: 'Punições pelo Descumprimento',
        content: 'Gestores que descumprem a LRF podem responder por crime de responsabilidade fiscal (Lei 10.028/2000), com penas que incluem multa, perda do cargo e inabilitação para função pública.',
        highlight: true,
      },
      {
        title: 'Dados da Lei',
        content: 'Lei Complementar 101/2000. Aplica-se a todos os entes federativos: União, estados e municípios.',
      },
    ],
  },
  {
    id: 'lia',
    title: 'Lei de Improbidade Administrativa',
    category: 'Leis',
    categoryId: 'leis',
    icon: '🚫',
    summary: 'A LIA pune agentes públicos que praticam atos desonestos, causam prejuízo ao erário ou violam princípios da administração pública — como honestidade, imparcialidade e eficiência.',
    sections: [
      {
        title: 'O que é Improbidade Administrativa?',
        content: 'É qualquer ato ilegal ou ímprobo praticado por agente público (servidor, político, gestor de empresa pública, etc.) que cause enriquecimento ilícito, dano ao erário ou violação de princípios como moralidade e legalidade.',
      },
      {
        title: 'Exemplos de Atos de Improbidade',
        items: [
          'Usar bem público para proveito pessoal (carro oficial, celular funcional)',
          'Receber propina ou vantagem indevida',
          'Contratar empresa sem licitação quando ela é obrigatória',
          'Desviar verbas públicas para fins privados',
          'Conceder benefício a quem não tem direito (clientelismo)',
          'Omitir-se no dever de prestar contas',
        ],
      },
      {
        title: 'Punições Previstas',
        items: [
          'Ressarcimento integral do dano causado ao erário',
          'Perda dos bens adquiridos de forma ilícita',
          'Multa civil de até 24x o valor do dano',
          'Suspensão dos direitos políticos (inelegibilidade)',
          'Proibição de contratar com o poder público',
          'Perda do cargo público',
        ],
        highlight: true,
      },
      {
        title: 'Dados da Lei',
        content: 'Lei 8.429/1992, reformada significativamente pela Lei 14.230/2021. Ação de improbidade é proposta pelo Ministério Público.',
      },
    ],
  },
];

export const ondeVouEntries: OndeVouEntry[] = [
  {
    id: 'trabalho',
    title: 'Direitos Violados no Trabalho',
    icon: '💼',
    direitos: {
      title: 'Direitos que podem estar sendo violados',
      items: [
        'Não pagamento de salário, hora extra ou benefícios',
        'Demissão irregular ou sem justa causa sem pagamento correto',
        'Assédio moral ou sexual no ambiente de trabalho',
        'Condições de trabalho insalubres ou perigosas sem adicional',
        'Não recolhimento do FGTS ou do INSS',
        'Jornada acima do limite legal sem compensação',
      ],
    },
    como_identificar: {
      content: 'Fique atento a situações como:',
      items: [
        'Seu empregador atrasa ou não paga o salário',
        'Você trabalha mais de 44 horas semanais sem receber hora extra',
        'Sofre pressão, humilhação ou ameaças constantes do superior',
        'O ambiente de trabalho tem riscos à sua saúde sem EPI adequado',
        'Você foi demitido mas não recebeu verbas rescisórias (aviso prévio, 13º proporcional, férias)',
      ],
    },
    o_que_fazer: [
      'Reúna provas: contracheques, cartão de ponto, mensagens, testemunhas',
      'Registre ocorrências em um diário com datas e descrições detalhadas',
      'Procure o sindicato da sua categoria para orientação gratuita',
      'Registre uma reclamação trabalhista no Ministério do Trabalho e Emprego',
      'Se necessário, ajuíze reclamação trabalhista na Justiça do Trabalho',
    ],
    onde_procurar: [
      { name: 'Sindicato da sua categoria', descricao: 'Representação gratuita e orientação jurídica sobre direitos trabalhistas', contato: 'Verifique o sindicato da sua área de atuação' },
      { name: 'Ministério do Trabalho e Emprego', descricao: 'Fiscalização e mediação de conflitos trabalhistas', contato: 'Portal empregabrasil.mte.gov.br' },
      { name: 'Defensoria Pública', descricao: 'Assistência jurídica gratuita para quem não pode pagar advogado', contato: 'Verifique a Defensoria do seu estado' },
      { name: 'Justiça do Trabalho', descricao: 'Você pode abrir reclamação trabalhista sem advogado em causas simples', contato: 'tst.jus.br' },
    ],
    orgaos: [
      { name: 'Ministério do Trabalho e Emprego (MTE)', tipo: 'Federal', descricao: 'Fiscaliza o cumprimento das leis trabalhistas' },
      { name: 'Delegacia Regional do Trabalho (DRT)', tipo: 'Regional', descricao: 'Recebe denúncias de violações trabalhistas' },
      { name: 'Tribunal Regional do Trabalho (TRT)', tipo: 'Judiciário', descricao: 'Julga conflitos entre empregados e empregadores' },
      { name: 'Ministério Público do Trabalho (MPT)', tipo: 'MP', descricao: 'Atua em casos de trabalho escravo, infantil e assédio coletivo' },
    ],
  },
  {
    id: 'escola',
    title: 'Direitos Violados na Escola',
    icon: '🏫',
    direitos: {
      title: 'Direitos que podem estar sendo violados',
      items: [
        'Bullying ou cyberbullying por colegas ou funcionários',
        'Expulsão ou suspensão irregular sem processo adequado',
        'Falta de acessibilidade para alunos com deficiência',
        'Negação de matrícula por critérios ilegais',
        'Abuso ou assédio por parte de professores ou funcionários',
        'Nota ou avaliação injusta sem direito de recurso',
      ],
    },
    como_identificar: {
      content: 'Sinais de que um direito está sendo violado na escola:',
      items: [
        'A escola recusou a matrícula sem justificativa legal',
        'Você foi punido sem ter direito à defesa ou recurso',
        'Sofre ou testemunha agressões físicas ou verbais repetidas',
        'A escola não oferece condições mínimas de acessibilidade',
        'Um funcionário tem conduta inadequada com alunos',
      ],
    },
    o_que_fazer: [
      'Fale com os pais ou responsáveis e com a direção da escola',
      'Registre os episódios por escrito com datas e descrições',
      'Encaminhe reclamação formal à Secretaria de Educação do município ou estado',
      'Para casos de abuso ou negligência, acione o Conselho Tutelar',
      'Em situações graves, procure o Ministério Público ou a Delegacia',
    ],
    onde_procurar: [
      { name: 'Direção e Coordenação da Escola', descricao: 'Primeira instância — registre tudo por escrito e peça posicionamento formal', contato: 'Dirija-se à escola' },
      { name: 'Secretaria de Educação', descricao: 'Órgão que supervisiona as escolas públicas municipais e estaduais', contato: 'Site da prefeitura ou governo do estado' },
      { name: 'Conselho Tutelar', descricao: 'Responsável por garantir os direitos de crianças e adolescentes', contato: 'Ligue 100 (Direitos Humanos) ou procure o CT do seu município' },
      { name: 'Ministério Público', descricao: 'Para casos graves de violação de direitos', contato: 'mpf.mp.br ou MP do seu estado' },
    ],
    orgaos: [
      { name: 'Conselho Tutelar', tipo: 'Municipal', descricao: 'Zela pelos direitos de crianças e adolescentes nas escolas' },
      { name: 'Secretaria de Educação', tipo: 'Estadual/Municipal', descricao: 'Supervisiona escolas públicas e pode investigar irregularidades' },
      { name: 'MEC — Ministério da Educação', tipo: 'Federal', descricao: 'Para questões de escolas federais e políticas nacionais' },
      { name: 'Disque 100', tipo: 'Federal', descricao: 'Denúncias de violações de direitos de crianças e adolescentes (gratuito, 24h)' },
    ],
  },
  {
    id: 'saude',
    title: 'Direitos Violados na Saúde',
    icon: '🏥',
    direitos: {
      title: 'Direitos que podem estar sendo violados',
      items: [
        'Recusa de atendimento de emergência no SUS',
        'Fila excessiva sem previsão de atendimento',
        'Falta de medicamento prescrito pelo médico',
        'Negativa de plano de saúde para procedimento necessário',
        'Erro médico ou negligência no atendimento',
        'Falta de informação sobre diagnóstico ou tratamento',
      ],
    },
    como_identificar: {
      content: 'Situações que indicam violação do direito à saúde:',
      items: [
        'Uma unidade de saúde se recusa a atender em caso de emergência',
        'O médico não explica seu diagnóstico, tratamento ou medicação',
        'O plano de saúde nega cobertura para procedimento indicado pelo médico',
        'Você aguarda há muito tempo por cirurgia ou consulta especializada',
        'Houve erro no procedimento ou na medicação administrada',
      ],
    },
    o_que_fazer: [
      'Para emergências: qualquer UPA ou hospital do SUS é obrigado a atender',
      'Registre reclamação na ouvidoria do estabelecimento de saúde',
      'Ligue para o Disque Saúde (136) para orientações e reclamações',
      'Para planos de saúde: acione a ANS (Agência Nacional de Saúde Suplementar)',
      'Para casos de erro médico: registre boletim de ocorrência e busque advogado',
    ],
    onde_procurar: [
      { name: 'Ouvidoria do SUS', descricao: 'Recebe reclamações sobre serviços de saúde pública', contato: 'Disque Saúde: 136 (gratuito, 24h)' },
      { name: 'ANS — Agência Nacional de Saúde Suplementar', descricao: 'Regula planos de saúde e resolve conflitos entre paciente e plano', contato: 'ans.gov.br ou 0800 701 9656' },
      { name: 'Conselho Regional de Medicina (CRM)', descricao: 'Para denúncias de conduta inadequada de médicos', contato: 'Site do CRM do seu estado' },
      { name: 'Ministério Público', descricao: 'Para casos graves ou coletivos de violação do direito à saúde', contato: 'MP do seu estado' },
    ],
    orgaos: [
      { name: 'Ministério da Saúde', tipo: 'Federal', descricao: 'Políticas nacionais de saúde e SUS' },
      { name: 'ANS', tipo: 'Federal', descricao: 'Regula os planos de saúde privados' },
      { name: 'Anvisa', tipo: 'Federal', descricao: 'Fiscaliza alimentos, medicamentos e estabelecimentos de saúde' },
      { name: 'CRM / CFM', tipo: 'Conselho', descricao: 'Regulam a ética e conduta médica' },
    ],
  },
  {
    id: 'seguranca-publica',
    title: 'Direitos Violados na Segurança Pública',
    icon: '🚔',
    direitos: {
      title: 'Direitos que podem estar sendo violados',
      items: [
        'Abuso de autoridade por parte de policiais',
        'Prisão ilegal — sem flagrante ou mandado judicial',
        'Tortura ou tratamento degradante sob custódia',
        'Revistas vexatórias ou discriminatórias',
        'Uso excessivo de força em abordagens',
        'Omissão de socorro ou negligência policial',
      ],
    },
    como_identificar: {
      content: 'Situações que configuram abuso de autoridade ou violação de direitos:',
      items: [
        'Você foi preso sem ser flagrado em crime e sem ordem judicial',
        'Foi agredido ou ameaçado por policial durante abordagem',
        'Passou por revista humilhante sem justificativa',
        'Seus pertences foram apreendidos sem recibo',
        'A polícia se recusou a registrar seu boletim de ocorrência',
      ],
    },
    o_que_fazer: [
      'Se possível, grave áudio ou vídeo da abordagem (é seu direito)',
      'Anote o nome, matrícula e viatura do agente',
      'Registre boletim de ocorrência sobre o abuso',
      'Procure a Ouvidoria da Polícia do seu estado',
      'Acione a Defensoria Pública ou OAB para assistência jurídica',
    ],
    onde_procurar: [
      { name: 'Ouvidoria da Polícia', descricao: 'Recebe denúncias de abusos cometidos por policiais', contato: 'Verifique o site da Secretaria de Segurança Pública do seu estado' },
      { name: 'Corregedoria da Polícia', descricao: 'Investiga irregularidades cometidas por policiais', contato: 'Secretaria de Segurança Pública estadual' },
      { name: 'Defensoria Pública', descricao: 'Assistência jurídica gratuita para vítimas de abuso policial', contato: 'Defensoria Pública do seu estado' },
      { name: 'Ministério Público', descricao: 'Investiga crimes cometidos por agentes públicos', contato: 'MP do seu estado' },
    ],
    orgaos: [
      { name: 'Ouvidoria da Polícia', tipo: 'Estadual', descricao: 'Investigação de abuso policial' },
      { name: 'Corregedoria', tipo: 'Interna/Estadual', descricao: 'Disciplina interna das forças policiais' },
      { name: 'Ministério Público', tipo: 'MP', descricao: 'Ação penal contra servidores que cometem crimes' },
      { name: 'OAB — Ordem dos Advogados do Brasil', tipo: 'Conselho', descricao: 'Orientação jurídica e defesa em casos de abuso de autoridade' },
    ],
  },
  {
    id: 'moradia',
    title: 'Direitos Violados na Moradia',
    icon: '🏠',
    direitos: {
      title: 'Direitos que podem estar sendo violados',
      items: [
        'Despejo irregular sem processo judicial',
        'Falta de saneamento básico no imóvel alugado',
        'Conflito de posse ou propriedade de terra',
        'Cobrança abusiva de aluguel ou encargos',
        'Reintegração de posse sem aviso ou assistência',
        'Falta de acesso a programas habitacionais públicos',
      ],
    },
    como_identificar: {
      content: 'Situações que indicam violação do direito à moradia:',
      items: [
        'O proprietário ameaça te expulsar sem processo judicial',
        'O imóvel não tem água encanada, esgoto ou energia',
        'Você foi removido sem notificação prévia e sem alternativa habitacional',
        'Há cobrança por serviços que não foram contratados',
      ],
    },
    o_que_fazer: [
      'Nenhum despejo pode ocorrer sem ordem judicial — questione imediatamente',
      'Procure a Defensoria Pública para assistência gratuita em conflitos de moradia',
      'Registre o estado do imóvel com fotos e documentos',
      'Para programas habitacionais, informe-se na prefeitura ou CAIXA',
      'Para questões de saneamento, acione a Secretaria de Obras ou SABESP/SANEPAR',
    ],
    onde_procurar: [
      { name: 'Defensoria Pública', descricao: 'Assistência jurídica gratuita em conflitos de moradia e despejos', contato: 'Defensoria Pública do seu estado' },
      { name: 'Prefeitura — Secretaria de Habitação', descricao: 'Programas habitacionais e regularização fundiária', contato: 'Site da prefeitura do seu município' },
      { name: 'CAIXA Econômica Federal', descricao: 'Programas como Minha Casa Minha Vida', contato: 'caixa.gov.br ou 0800 726 0101' },
      { name: 'Ministério Público', descricao: 'Para despejos coletivos e violações em massa do direito à moradia', contato: 'MP do seu estado' },
    ],
    orgaos: [
      { name: 'Secretaria de Habitação', tipo: 'Municipal/Estadual', descricao: 'Programas de habitação e regularização fundiária' },
      { name: 'CAIXA Econômica Federal', tipo: 'Federal', descricao: 'Financiamento habitacional e programas sociais' },
      { name: 'Defensoria Pública', tipo: 'Estadual', descricao: 'Defesa jurídica em conflitos de moradia' },
      { name: 'Ministério das Cidades', tipo: 'Federal', descricao: 'Política nacional de habitação' },
    ],
  },
  {
    id: 'alimentacao',
    title: 'Direitos Violados na Alimentação',
    icon: '🍽️',
    direitos: {
      title: 'Direitos que podem estar sendo violados',
      items: [
        'Insegurança alimentar grave — não ter o que comer',
        'Venda de alimento vencido, contaminado ou falsificado',
        'Propaganda enganosa sobre alimentos',
        'Falta de acesso a programas de assistência alimentar',
        'Violação das normas sanitárias em estabelecimentos',
      ],
    },
    como_identificar: {
      content: 'Situações que indicam violação do direito à alimentação:',
      items: [
        'Você encontrou produto com prazo de validade vencido à venda',
        'O produto causou doença ou intoxicação',
        'A propaganda do produto induzia a erro sobre seu conteúdo',
        'Você ou sua família passa por insegurança alimentar grave',
      ],
    },
    o_que_fazer: [
      'Para alimento contaminado: guarde o produto como prova e procure o Procon',
      'Para propaganda enganosa: denuncie ao Procon e ao CONAR',
      'Para insegurança alimentar: procure o CRAS (Centro de Referência de Assistência Social) do seu município',
      'Para violações sanitárias: denuncie à Vigilância Sanitária local',
    ],
    onde_procurar: [
      { name: 'Procon', descricao: 'Defesa do consumidor contra alimentos irregulares ou propaganda enganosa', contato: 'Procon do seu estado ou consumidor.gov.br' },
      { name: 'Vigilância Sanitária (Anvisa)', descricao: 'Fiscaliza alimentos, estabelecimentos e higiene', contato: '0800 722 7216 ou anvisa.gov.br' },
      { name: 'CRAS — Centro de Referência de Assistência Social', descricao: 'Auxílio para famílias em insegurança alimentar', contato: 'Prefeitura do seu município' },
      { name: 'Ministério do Desenvolvimento Social', descricao: 'Programas como Bolsa Família e Alimenta Brasil', contato: 'gov.br/cidadania' },
    ],
    orgaos: [
      { name: 'Anvisa', tipo: 'Federal', descricao: 'Fiscalização de alimentos e bebidas' },
      { name: 'Procon', tipo: 'Estadual/Municipal', descricao: 'Defesa do consumidor' },
      { name: 'CRAS', tipo: 'Municipal', descricao: 'Assistência social e segurança alimentar' },
      { name: 'Vigilância Sanitária Local', tipo: 'Municipal', descricao: 'Fiscaliza estabelecimentos de alimentação' },
    ],
  },
  {
    id: 'educacao',
    title: 'Direitos Violados na Educação',
    icon: '📖',
    direitos: {
      title: 'Direitos que podem estar sendo violados',
      items: [
        'Negação de matrícula em escola pública',
        'Falta de vagas na rede pública de ensino',
        'Escola sem condições mínimas de funcionamento (sem água, banheiro, sala)',
        'Ausência de profissional de apoio para aluno com deficiência',
        'Evasão escolar sem ação do poder público',
        'Discriminação ou exclusão de aluno por religião, raça, deficiência ou orientação',
      ],
    },
    como_identificar: {
      content: 'Situações que indicam violação do direito à educação:',
      items: [
        'A escola se recusou a matricular sem justificativa legal',
        'Seu filho (ou você) não conseguiu vaga em escola pública próxima',
        'A escola não tem professor para determinada disciplina há semanas',
        'Aluno com deficiência não tem suporte adequado',
      ],
    },
    o_que_fazer: [
      'Solicite vaga formalmente por escrito à Secretaria de Educação',
      'Se recusado, recorra ao Ministério Público para garantir o direito à matrícula por ação judicial',
      'Denuncie à Secretaria de Educação sobre condições precárias da escola',
      'Para casos de discriminação, procure o Conselho Tutelar e o MP',
      'Para alunos com deficiência sem suporte: acione a Defensoria Pública',
    ],
    onde_procurar: [
      { name: 'Secretaria de Educação', descricao: 'Responsável pelas escolas públicas — municipal para fundamental I e II, estadual para ensino médio', contato: 'Site da prefeitura ou governo estadual' },
      { name: 'Conselho Municipal de Educação', descricao: 'Órgão de controle social da educação no município', contato: 'Prefeitura do seu município' },
      { name: 'Ministério Público', descricao: 'Pode garantir vaga escolar por ação judicial em casos de negação de matrícula', contato: 'MP do seu estado' },
      { name: 'Defensoria Pública', descricao: 'Assistência jurídica gratuita para garantir acesso à educação', contato: 'Defensoria Pública do seu estado' },
    ],
    orgaos: [
      { name: 'Secretaria Municipal de Educação', tipo: 'Municipal', descricao: 'Ensino infantil e fundamental' },
      { name: 'Secretaria Estadual de Educação', tipo: 'Estadual', descricao: 'Ensino médio e parte do fundamental' },
      { name: 'MEC', tipo: 'Federal', descricao: 'Políticas nacionais de educação' },
      { name: 'Conselho Tutelar', tipo: 'Municipal', descricao: 'Combate à evasão e violação de direitos de crianças na escola' },
    ],
  },
];

export function getContentById(id: string): ContentEntry | undefined {
  return contentEntries.find((e) => e.id === id);
}

export function getOndeVouById(id: string): OndeVouEntry | undefined {
  return ondeVouEntries.find((e) => e.id === id);
}
