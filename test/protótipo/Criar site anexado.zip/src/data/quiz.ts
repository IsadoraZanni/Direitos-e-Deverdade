export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export interface QuizCategory {
  id: string;
  title: string;
  description: string;
  icon: string;
  questions: QuizQuestion[];
}

export const quizCategories: QuizCategory[] = [
  {
    id: 'leis',
    title: 'Leis',
    description: 'Teste seus conhecimentos sobre as principais leis brasileiras.',
    icon: '📜',
    questions: [
      {
        id: 'leis-1',
        question: 'Qual é o apelido da Constituição Federal de 1988?',
        options: [
          'Constituição do Povo',
          'Constituição Cidadã',
          'Constituição Democrática',
          'Constituição Nacional',
        ],
        correct: 1,
        explanation: 'A Constituição de 1988 ficou conhecida como "Constituição Cidadã" porque foi a primeira a ampliar de forma tão expressiva os direitos e garantias fundamentais dos brasileiros após a ditadura militar.',
      },
      {
        id: 'leis-2',
        question: 'O Código de Defesa do Consumidor garante o direito de arrependimento em compras feitas fora do estabelecimento (ex: online) por até:',
        options: [
          '3 dias corridos',
          '5 dias úteis',
          '7 dias corridos',
          '10 dias úteis',
        ],
        correct: 2,
        explanation: 'O CDC (Art. 49) garante 7 dias corridos a partir da entrega do produto ou celebração do contrato para o consumidor desistir de compras feitas fora do estabelecimento, sem precisar dar nenhuma justificativa.',
      },
      {
        id: 'leis-3',
        question: 'De acordo com o ECA, qual é a idade máxima para ser considerado "criança" (e não adolescente)?',
        options: [
          'Menos de 10 anos',
          'Menos de 12 anos',
          'Menos de 14 anos',
          'Menos de 16 anos',
        ],
        correct: 1,
        explanation: 'O ECA (Lei 8.069/1990, Art. 2º) define criança como a pessoa com até 12 anos incompletos e adolescente como aquela entre 12 e 18 anos.',
      },
      {
        id: 'leis-4',
        question: 'Qual lei brasileira criou mecanismos para prevenir e punir a violência doméstica e familiar contra a mulher?',
        options: [
          'Lei de Acesso à Informação',
          'Estatuto do Idoso',
          'Lei Maria da Penha',
          'Lei de Responsabilidade Fiscal',
        ],
        correct: 2,
        explanation: 'A Lei 11.340/2006, conhecida como Lei Maria da Penha, criou mecanismos para coibir e prevenir a violência doméstica e familiar contra a mulher. O nome é uma homenagem a Maria da Penha Maia Fernandes.',
      },
    ],
  },
  {
    id: 'direitos',
    title: 'Direitos e Deveres',
    description: 'Saiba o que você tem direito e quais são seus deveres como cidadão.',
    icon: '⚖️',
    questions: [
      {
        id: 'direitos-1',
        question: 'O voto é OBRIGATÓRIO para brasileiros com qual faixa etária?',
        options: [
          'De 16 a 65 anos',
          'De 18 a 70 anos',
          'De 21 a 65 anos',
          'De 18 a 65 anos',
        ],
        correct: 1,
        explanation: 'O voto é obrigatório para brasileiros alfabetizados entre 18 e 70 anos. É facultativo (opcional) para maiores de 70 anos, jovens de 16 e 17 anos, e analfabetos.',
      },
      {
        id: 'direitos-2',
        question: 'Qual é o período mínimo de férias garantido por lei ao trabalhador com carteira assinada?',
        options: [
          '15 dias',
          '20 dias',
          '30 dias',
          '45 dias',
        ],
        correct: 2,
        explanation: 'A CLT garante 30 dias corridos de férias remuneradas por ano de trabalho. O trabalhador recebe, além do salário normal, um adicional de ⅓ (um terço) sobre o valor das férias.',
      },
      {
        id: 'direitos-3',
        question: 'O consumidor tem garantia legal de quantos dias em produtos DURÁVEIS (eletrodomésticos, eletrônicos)?',
        options: [
          '30 dias',
          '60 dias',
          '90 dias',
          '180 dias',
        ],
        correct: 2,
        explanation: 'O CDC garante garantia legal de 90 dias para produtos duráveis (geladeiras, celulares, TVs, etc.) e 30 dias para produtos não duráveis (alimentos, cosméticos). Essa garantia é adicional à garantia contratual do fabricante.',
      },
      {
        id: 'direitos-4',
        question: 'Qual percentual mínimo de vagas em concursos públicos deve ser reservado para pessoas com deficiência?',
        options: [
          '3%',
          '5%',
          '10%',
          '15%',
        ],
        correct: 1,
        explanation: 'A Constituição Federal (Art. 37, VIII) garante reserva de vagas para pessoas com deficiência em concursos públicos, fixada em lei — normalmente 5%, mas nunca inferior a este percentual.',
      },
    ],
  },
  {
    id: 'agentes',
    title: 'Funções de Agentes Públicos',
    description: 'Descubra quem faz o quê no governo e como funciona o poder público.',
    icon: '🏛️',
    questions: [
      {
        id: 'agentes-1',
        question: 'Qual é a função principal do Vereador?',
        options: [
          'Governar o estado',
          'Criar leis municipais e fiscalizar a prefeitura',
          'Representar o Brasil no exterior',
          'Gerenciar o orçamento federal',
        ],
        correct: 1,
        explanation: 'O Vereador integra o Poder Legislativo municipal (Câmara Municipal). Sua função principal é criar, aprovar e revogar leis municipais, além de fiscalizar o Prefeito e a administração da cidade.',
      },
      {
        id: 'agentes-2',
        question: 'Quantos Senadores cada estado e o Distrito Federal têm no Senado Federal?',
        options: [
          '1 Senador',
          '2 Senadores',
          '3 Senadores',
          '4 Senadores',
        ],
        correct: 2,
        explanation: 'Diferente da Câmara dos Deputados (proporcional à população), o Senado Federal garante representação igualitária: cada um dos 26 estados e o DF tem exatamente 3 senadores, totalizando 81 senadores.',
      },
      {
        id: 'agentes-3',
        question: 'Qual é o mandato de um Senador?',
        options: [
          '4 anos',
          '6 anos',
          '8 anos',
          '10 anos',
        ],
        correct: 2,
        explanation: 'O mandato do Senador é de 8 anos, com renovações alternadas de ⅓ e ⅔ a cada 4 anos. Isso significa que nem todos os senadores são trocados na mesma eleição, garantindo continuidade no Senado.',
      },
      {
        id: 'agentes-4',
        question: 'O Presidente da República é o chefe de qual Poder?',
        options: [
          'Poder Judiciário',
          'Poder Legislativo',
          'Poder Executivo Federal',
          'Poder Moderador',
        ],
        correct: 2,
        explanation: 'O Presidente da República é o chefe do Poder Executivo Federal. O Poder Legislativo é exercido pelo Congresso Nacional (Câmara + Senado) e o Judiciário pelo STF, STJ e demais tribunais.',
      },
    ],
  },
];

export function getCategoryById(id: string): QuizCategory | undefined {
  return quizCategories.find((c) => c.id === id);
}
