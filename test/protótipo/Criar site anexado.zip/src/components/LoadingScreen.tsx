export default function LoadingScreen() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center min-h-[50vh] gap-5">
      <div className="relative">
        <div className="w-12 h-12 rounded-full border-4 border-[#EEF2FA] border-t-[#1B3A6B] spinner" />
      </div>
      <p className="text-[#6B7A8D] text-sm font-medium pulse-anim">
        Carregando conteúdo...
      </p>
    </div>
  );
}
