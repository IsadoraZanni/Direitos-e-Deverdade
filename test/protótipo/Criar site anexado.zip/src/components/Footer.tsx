import type { Page } from '../App';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-[#1B3A6B] text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div className="col-span-1">
            <p className="font-display text-xl text-white mb-2">
              Direitos <span className="text-[#4ADEAA]">DeVerdade</span>
            </p>
            <p className="text-white/70 text-sm leading-relaxed">
              Facilitando o acesso da população a informações sobre direitos, deveres, leis e funções dos agentes públicos — de forma simples, clara e acessível.
            </p>
          </div>

          {/* Links */}
          <div>
            <p className="font-semibold text-white/90 mb-4 text-sm uppercase tracking-wide">
              Navegação
            </p>
            <ul className="space-y-2.5">
              {[
                { label: 'Início', action: () => onNavigate({ type: 'home' }) },
                { label: 'Quem somos', action: () => onNavigate({ type: 'quem-somos', section: 'sobre' }) },
                { label: 'Quiz', action: () => onNavigate({ type: 'quiz', stage: 'menu' }) },
                { label: 'Contato', action: () => onNavigate({ type: 'quem-somos', section: 'contato' }) },
                { label: 'Fontes e referências', action: () => onNavigate({ type: 'quem-somos', section: 'fontes' }) },
              ].map((link) => (
                <li key={link.label}>
                  <button
                    onClick={link.action}
                    className="text-white/70 hover:text-[#4ADEAA] transition-colors duration-150 text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <p className="font-semibold text-white/90 mb-4 text-sm uppercase tracking-wide">
              Contato
            </p>
            <div className="space-y-2.5 text-sm text-white/70">
              <div className="flex items-center gap-2">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4 flex-shrink-0">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                <span>contato@direitosdeverdade.org</span>
              </div>
              <p className="mt-4 text-xs text-white/50 leading-relaxed">
                As informações deste site possuem finalidade informativa e educacional.
              </p>
            </div>
          </div>
        </div>

        {/* Aviso */}
        <div className="mt-10 pt-6 border-t border-white/15">
          <div className="bg-white/10 rounded-xl px-5 py-4 mb-6">
            <p className="text-sm text-white/80 leading-relaxed">
              <span className="font-semibold text-white">⚠️ Aviso importante: </span>
              O conteúdo deste site possui finalidade{' '}
              <strong>informativa e educacional</strong> e não substitui orientação jurídica profissional. Para questões legais específicas, consulte um advogado.
            </p>
          </div>
          <p className="text-center text-xs text-white/40">
            © 2026 Direitos DeVerdade. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
