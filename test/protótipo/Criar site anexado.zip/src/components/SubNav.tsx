import { useState, useRef } from 'react';
import type { Page } from '../App';

interface SubNavProps {
  onNavigate: (page: Page) => void;
}

const menuItems = [
  { label: 'Sobre o projeto', section: 'sobre' as const },
  { label: 'Nossa missão', section: 'missao' as const },
  { label: 'Equipe', section: 'equipe' as const },
  { label: 'Instituição', section: 'instituicao' as const },
  { label: 'Fontes e referências', section: 'fontes' as const },
  { label: 'Contato', section: 'contato' as const },
  { label: 'Aviso importante', section: 'aviso' as const },
];

export default function SubNav({ onNavigate }: SubNavProps) {
  const [open, setOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleMouseEnter = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };

  const handleMouseLeave = () => {
    closeTimer.current = setTimeout(() => setOpen(false), 150);
  };

  const handleSelect = (section: typeof menuItems[number]['section']) => {
    setOpen(false);
    onNavigate({ type: 'quem-somos', section });
  };

  return (
    <nav
      className="fixed top-16 left-0 right-0 z-40 bg-white border-b border-[#D5DCE8] shadow-sm"
      aria-label="Navegação secundária"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center h-11 relative">
          {/* Quem somos dropdown trigger */}
          <div
            className="relative"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <button
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-[#1B3A6B]/30 ${
                open
                  ? 'text-[#1B3A6B] bg-[#EEF2FA]'
                  : 'text-[#1B3A6B] hover:bg-[#EEF2FA]'
              }`}
              aria-haspopup="true"
              aria-expanded={open}
            >
              <span>Quem somos</span>
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className={`w-3.5 h-3.5 transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
              >
                <path d="M6 9l6 6 6-6" />
              </svg>
            </button>

            {/* Dropdown menu */}
            {open && (
              <div
                className="absolute top-full left-0 mt-1 w-56 bg-white rounded-xl border border-[#D5DCE8] shadow-xl py-1.5 z-50"
                role="menu"
              >
                {menuItems.map((item) => (
                  <button
                    key={item.section}
                    onClick={() => handleSelect(item.section)}
                    role="menuitem"
                    className="w-full text-left px-4 py-2.5 text-sm text-[#0F1C2E] hover:bg-[#EEF2FA] hover:text-[#1B3A6B] transition-colors duration-150 font-medium"
                  >
                    {item.label}
                    {item.section === 'aviso' && (
                      <span className="ml-2 text-xs bg-[#FEF3C7] text-[#92400E] px-1.5 py-0.5 rounded font-semibold">
                        !
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
