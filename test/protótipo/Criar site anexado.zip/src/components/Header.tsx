import type { Page } from '../App';

interface HeaderProps {
  onHome: () => void;
  onNavigate: (page: Page) => void;
  currentPage: Page;
}

export default function Header({ onHome, onNavigate, currentPage }: HeaderProps) {
  const isQuiz = currentPage.type === 'quiz';

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#1B3A6B] shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo + Name */}
          <button
            onClick={onHome}
            className="flex items-center gap-3 group focus:outline-none"
            aria-label="Voltar para a página inicial"
          >
            {/* Logo placeholder circle */}
            <div className="w-10 h-10 rounded-full bg-white/15 border-2 border-white/30 flex items-center justify-center flex-shrink-0 group-hover:bg-white/25 transition-colors duration-200">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-5 h-5 text-white"
              >
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
            {/* Site name */}
            <div className="text-left">
              <span className="font-display text-lg text-white leading-tight block">
                Direitos{' '}
                <span className="text-[#4ADEAA]">DeVerdade</span>
              </span>
            </div>
          </button>

          {/* Quiz button */}
          <button
            onClick={() => onNavigate({ type: 'quiz', stage: 'menu' })}
            aria-pressed={isQuiz}
            className={`flex items-center gap-2 px-5 py-2 rounded-lg font-semibold text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-white/50 ${
              isQuiz
                ? 'bg-white text-[#1B3A6B]'
                : 'bg-[#009C5B] hover:bg-[#007a47] text-white'
            }`}
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
              <path d="M12 17h.01" />
            </svg>
            Quiz
          </button>
        </div>
      </div>
    </header>
  );
}
