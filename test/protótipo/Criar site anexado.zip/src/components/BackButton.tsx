interface BackButtonProps {
  onBack: () => void;
  label?: string;
}

export default function BackButton({ onBack, label = 'Voltar' }: BackButtonProps) {
  return (
    <button
      onClick={onBack}
      className="inline-flex items-center gap-2 text-sm font-medium text-[#1B3A6B] hover:text-[#009C5B] transition-colors duration-150 group focus:outline-none"
      aria-label={label}
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform duration-150"
      >
        <path d="M19 12H5" />
        <path d="M12 19l-7-7 7-7" />
      </svg>
      {label}
    </button>
  );
}
