Crie um protótipo de site **completo, moderno, responsivo e totalmente clicável** para o projeto **“Direitos DeVerdade”**.

O objetivo do site é facilitar o acesso da população a informações sobre **direitos, deveres, leis e funções dos agentes públicos**, utilizando uma linguagem simples, organização visual clara e navegação intuitiva.

O protótipo deve ser **funcional dentro do Figma**, com telas conectadas, interações de clique, estados de hover, expansão de menus e transições entre páginas. Não crie apenas uma representação visual estática.

## 1. IDENTIDADE E ESTILO VISUAL

Nome do site: **Direitos DeVerdade**

Criar uma identidade visual que transmita:

* confiança;
* acessibilidade;
* cidadania;
* clareza;
* educação;
* transparência.

Utilizar uma interface moderna, limpa e profissional, mas sem parecer excessivamente corporativa.

Priorizar:

* boa hierarquia visual;
* textos fáceis de ler;
* espaçamento confortável;
* cards com cantos levemente arredondados;
* ícones simples e intuitivos;
* boa utilização de cores;
* contraste adequado;
* aparência acessível para diferentes públicos.

Reservar, no canto superior esquerdo, um espaço circular para o **logotipo**, pois o logotipo definitivo ainda não foi desenvolvido.

Ao lado do espaço do logotipo, apresentar o nome:

**Direitos DeVerdade**

---

# 2. CABEÇALHO PRINCIPAL

Criar um cabeçalho fixo no topo da página.

### Lado esquerdo

* Espaço circular reservado para o logotipo.
* Nome **Direitos DeVerdade** ao lado do logotipo.

O nome deve funcionar como botão de retorno à página inicial.

### Lado direito

Adicionar uma opção:

**Quiz**

Essa opção deve ser claramente clicável.

Ao clicar em **Quiz**, o usuário deve ser levado para uma tela específica do quiz contendo três grandes opções:

1. **Leis**
2. **Direitos e deveres**
3. **Funções de agentes públicos**

Cada uma dessas opções deve ser clicável e direcionar para uma tela correspondente ao tema.

---

# 3. SUBMENU “QUEM SOMOS”

Abaixo do cabeçalho principal, criar uma segunda barra de navegação.

Adicionar:

**Quem somos ↓**

O submenu deve possuir comportamento de hover:

**Ao passar o mouse sobre “Quem somos”, abrir um menu suspenso.**

O menu deve conter:

* **Sobre o projeto**
* **Nossa missão**
* **Equipe**
* **Instituição**
* **Fontes e referências**
* **Contato**
* **Aviso importante**

Cada opção deve possuir um estado visual de hover e ser clicável.

### Sobre o projeto

Tela explicando brevemente:

* o que é o Direitos DeVerdade;
* qual problema o projeto pretende resolver;
* por que facilitar o acesso à informação sobre direitos é importante.

### Nossa missão

Apresentar a missão do projeto:

Tornar informações sobre direitos, deveres, leis e serviços públicos mais acessíveis, compreensíveis e fáceis de encontrar.

### Equipe

Criar uma área reservada para apresentar os integrantes responsáveis pelo projeto.

Utilizar cards individuais contendo:

* nome;
* função;
* formação ou área;
* espaço reservado para foto, caso necessário.

### Instituição

Criar uma seção para apresentar a instituição/curso relacionado ao projeto.

Deixar a estrutura preparada para inserir:

* nome da instituição;
* curso;
* informações adicionais;
* logotipo institucional.

### Fontes e referências

Criar uma tela específica para apresentar as fontes utilizadas pelo projeto.

Organizar as referências de forma clara, incluindo categorias como:

* Constituição Federal;
* legislação brasileira;
* portais oficiais;
* órgãos públicos;
* outras fontes utilizadas na elaboração do conteúdo.

### Contato

Criar uma tela com:

* e-mail de contato;
* formulário simples de contato;
* campo para nome;
* campo para e-mail;
* campo para mensagem;
* botão “Enviar”.

### Aviso importante

Criar um aviso visual informando que o site possui finalidade **informativa e educacional** e que seu conteúdo **não substitui orientação jurídica profissional**.

---

# 4. PÁGINA INICIAL — BODY

No corpo principal da página inicial, criar **quatro cards grandes centrais**.

Os quatro cards devem possuir tamanho visual semelhante e formar uma composição organizada e equilibrada.

Cards:

### Card 1 — Direitos e deveres

Ao passar o mouse sobre o card, criar uma animação de expansão/elevação e revelar os minicards relacionados ao tema.

Minicards:

* Direitos e deveres dos cidadãos
* Direitos e deveres dos trabalhadores
* Direitos e deveres dos consumidores
* Direitos e deveres dos estudantes
* Direitos e deveres dos idosos
* Direitos e deveres das crianças e adolescentes
* Direitos e deveres das pessoas com deficiência

O card grande **não deve possuir uma ação de navegação própria**.

Somente os minicards devem ser clicáveis.

---

### Card 2 — Funções de agentes públicos

Ao passar o mouse sobre o card, revelar os minicards.

Minicards:

* Funções do Presidente da República
* Funções do Governador
* Funções do Prefeito
* Funções do Deputado Federal
* Funções do Deputado Estadual
* Funções do Senador
* Funções do Vereador

O card principal não deve navegar para outra tela.

Somente os minicards devem ser clicáveis.

---

### Card 3 — Leis

Ao passar o mouse sobre o card, revelar os minicards.

Minicards:

* Constituição Federal
* Código Civil
* Código Penal
* Código de Defesa do Consumidor
* Estatuto da Criança e do Adolescente
* Estatuto do Idoso
* Lei Maria da Penha
* Lei de Acesso à Informação
* Lei de Responsabilidade Fiscal
* Lei de Improbidade Administrativa

O card principal não deve possuir ação de navegação.

Somente os minicards devem ser clicáveis.

---

### Card 4 — Onde vou se meu direito for ferido?

Ao passar o mouse sobre o card, revelar os minicards.

Minicards:

* Direitos violados no trabalho
* Direitos violados na escola
* Direitos violados na saúde
* Direitos violados na segurança pública
* Direitos violados na moradia
* Direitos violados na alimentação
* Direitos violados na educação

O card principal não deve possuir ação de navegação.

Somente os minicards devem ser clicáveis.

---

# 5. COMPORTAMENTO DOS CARDS

É fundamental que o protótipo represente corretamente os estados de interação.

Estado padrão:

* card fechado;
* título;
* ícone;
* breve descrição.

Estado hover:

* card ganha destaque;
* realizar uma pequena elevação;
* alterar suavemente a sombra ou borda;
* revelar os minicards;
* utilizar uma transição suave.

Os minicards devem possuir:

* estado normal;
* estado hover;
* estado pressionado/clicado.

**Não transformar o card grande em um botão.**

A interação deve acontecer somente nos minicards.

---

# 6. TELAS DOS CONTEÚDOS

Cada minicard clicável deve levar para uma tela própria.

Criar uma estrutura de página consistente para essas telas.

Exemplo:

**Constituição Federal**

No topo:

* botão “← Voltar”;
* título da página;
* categoria correspondente.

No conteúdo:

* explicação resumida;
* principais informações;
* conceitos importantes;
* exemplos práticos;
* informações organizadas em cards ou blocos.

Utilizar linguagem simples e objetiva.

Não criar textos jurídicos excessivamente complexos.

Criar uma hierarquia visual clara entre:

* título;
* subtítulo;
* explicação;
* exemplos;
* informações importantes.

---

# 7. PÁGINAS DE “ONDE VOU SE MEU DIREITO FOR FERIDO?”

As páginas dessa categoria devem possuir uma estrutura um pouco diferente.

Exemplo:

**Direitos violados no trabalho**

Apresentar:

1. **Qual direito pode estar sendo violado?**
2. **Como identificar a situação?**
3. **O que posso fazer?**
4. **Onde procurar ajuda?**
5. **Quais órgãos podem ser procurados?**

Utilizar cards, passos numerados e elementos visuais para facilitar a compreensão.

Dar bastante destaque ao item:

**“Onde procurar ajuda?”**

---

# 8. QUIZ

Criar uma experiência de quiz funcional dentro do protótipo.

Ao clicar em **Quiz**, abrir uma tela inicial com:

**Teste seus conhecimentos**

Texto de apoio explicando brevemente o funcionamento.

Apresentar três categorias:

* Leis
* Direitos e deveres
* Funções de agentes públicos

Cada categoria deve ser clicável.

Depois da escolha, apresentar perguntas de múltipla escolha.

Cada pergunta deve possuir:

* enunciado;
* quatro alternativas;
* botão de confirmação;
* indicador de progresso.

Criar estados para:

* resposta correta;
* resposta incorreta;
* próxima pergunta;
* resultado final.

No final, apresentar:

* pontuação;
* quantidade de respostas corretas;
* mensagem de resultado;
* botão “Refazer quiz”;
* botão “Voltar para o início”.

---

# 9. CARREGAMENTOS E TRANSIÇÕES

O site deve parecer uma aplicação real.

Adicionar transições suaves entre as telas.

Sempre que uma nova página for aberta, utilizar uma transição curta e elegante.

Criar também uma tela/estado de carregamento para simular o carregamento dos conteúdos.

O carregamento deve possuir:

* indicador visual;
* animação simples;
* texto como “Carregando conteúdo...”.

Não utilizar carregamentos longos.

---

# 10. RODAPÉ

Criar um rodapé completo na página inicial e nas páginas internas.

O rodapé deve conter:

**Direitos DeVerdade**

Breve descrição do projeto.

Links:

* Início
* Quem somos
* Quiz
* Contato
* Fontes e referências

Contato:

* e-mail;
* espaço para outras informações de contato.

Adicionar também:

**Aviso importante**

“O conteúdo deste site possui finalidade informativa e educacional e não substitui orientação jurídica profissional.”

Na parte inferior:

**© 2026 Direitos DeVerdade. Todos os direitos reservados.**

---

# 11. NAVEGAÇÃO DO PROTÓTIPO

Configurar as interações no protótipo do Figma.

### Navegação obrigatória:

**Logo / Direitos DeVerdade**
→ Página inicial

**Quiz**
→ Tela do quiz

**Quem somos**
→ Menu dropdown ao passar o mouse

**Opções do menu Quem somos**
→ Respectivas páginas

**Minicards**
→ Respectiva página de conteúdo

**Botão voltar**
→ Página anterior

**Botão início**
→ Página inicial

**Quiz — categoria**
→ Perguntas da categoria

**Alternativa**
→ Estado de resposta

**Próxima pergunta**
→ Próxima pergunta

**Resultado**
→ Tela final do quiz

---

# 12. RESPONSIVIDADE

Criar o layout pensando em diferentes tamanhos de tela.

Desktop:

* quatro cards principais organizados de maneira equilibrada;
* navegação horizontal;
* submenu dropdown.

Tablet:

* reorganizar os cards para manter boa leitura.

Mobile:

* cards em coluna;
* menu adaptado;
* minicards organizados verticalmente;
* botões grandes o suficiente para toque;
* textos sem cortes.

---

# 13. ACESSIBILIDADE

Priorizar acessibilidade em toda a interface.

Utilizar:

* contraste adequado;
* fontes legíveis;
* tamanhos confortáveis;
* ícones acompanhados de texto quando necessário;
* áreas de clique suficientemente grandes;
* linguagem simples;
* hierarquia clara de títulos.

Não depender exclusivamente de cores para comunicar informações.

---

# 14. ORGANIZAÇÃO DO ARQUIVO FIGMA

Organizar o projeto utilizando componentes e variantes.

Criar componentes reutilizáveis para:

* Header;
* Footer;
* Card principal;
* Minicard;
* Botões;
* Menu dropdown;
* Breadcrumb;
* Cards de conteúdo;
* Questões do quiz;
* Indicadores de progresso;
* Estados de carregamento.

Criar variantes para os estados:

* Default;
* Hover;
* Active/Pressed;
* Disabled;
* Loading.

Nomear os componentes e frames de maneira clara e organizada.

---

# 15. OBJETIVO FINAL

O resultado deve parecer um **site real e navegável**, não apenas um mockup.

O usuário deve conseguir navegar pelo protótipo como se estivesse utilizando o site:

**Página inicial → categoria → minicard → conteúdo → voltar**

ou

**Página inicial → Quiz → categoria → perguntas → resultado**

ou

**Página inicial → Quem somos → informação desejada**

Todas as interações principais devem estar conectadas no modo Prototype do Figma.

Priorizar uma experiência simples, intuitiva, acessível e visualmente agradável, mantendo o foco principal do projeto: **facilitar o acesso da população a informações sobre seus direitos, deveres, leis e funcionamento do poder público.**
