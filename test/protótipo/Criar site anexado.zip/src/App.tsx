import { useState, useCallback, useRef, useEffect } from 'react';
import Header from './components/Header';
import SubNav from './components/SubNav';
import Footer from './components/Footer';
import LoadingScreen from './components/LoadingScreen';
import HomePage from './pages/HomePage';
import ContentPage from './pages/ContentPage';
import OndeVouPage from './pages/OndeVouPage';
import QuizPage from './pages/QuizPage';
import QuemSomosPage from './pages/QuemSomosPage';
import ContatoPage from './pages/ContatoPage';
import FontesPage from './pages/FontesPage';
import AvisoPage from './pages/AvisoPage';
import InstituicaoPage from './pages/InstituicaoPage';

export type Page =
  | { type: 'home' }
  | { type: 'content'; id: string }
  | { type: 'onde-vou'; id: string }
  | { type: 'quiz'; stage: 'menu' | 'playing' | 'result'; category?: string; question?: number; answers?: number[]; score?: number }
  | { type: 'quem-somos'; section: 'sobre' | 'missao' | 'equipe' | 'instituicao' | 'fontes' | 'contato' | 'aviso' };

export default function App() {
  const [page, setPage] = useState<Page>({ type: 'home' });
  const [isLoading, setIsLoading] = useState(false);
  const [pageKey, setPageKey] = useState(0);
  const history = useRef<Page[]>([]);
  const currentPage = useRef<Page>({ type: 'home' });

  useEffect(() => {
    currentPage.current = page;
  }, [page]);

  const navigate = useCallback((newPage: Page) => {
    history.current = [...history.current, currentPage.current];
    setIsLoading(true);
    const delay = newPage.type === page.type ? 200 : 400;
    setTimeout(() => {
      setPage(newPage);
      setPageKey((k) => k + 1);
      setIsLoading(false);
      window.scrollTo({ top: 0 });
    }, delay);
  }, [page.type]);

  const goBack = useCallback(() => {
    const prev = history.current[history.current.length - 1];
    history.current = history.current.slice(0, -1);
    if (prev) {
      setIsLoading(true);
      setTimeout(() => {
        setPage(prev);
        setPageKey((k) => k + 1);
        setIsLoading(false);
        window.scrollTo({ top: 0 });
      }, 300);
    } else {
      navigate({ type: 'home' });
    }
  }, [navigate]);

  const goHome = useCallback(() => {
    history.current = [];
    navigate({ type: 'home' });
  }, [navigate]);

  const renderPage = () => {
    if (isLoading) return <LoadingScreen />;

    switch (page.type) {
      case 'home':
        return <HomePage onNavigate={navigate} />;

      case 'content':
        return <ContentPage id={page.id} onBack={goBack} onHome={goHome} />;

      case 'onde-vou':
        return <OndeVouPage id={page.id} onBack={goBack} onHome={goHome} />;

      case 'quiz':
        return (
          <QuizPage
            stage={page.stage}
            category={page.category}
            question={page.question}
            answers={page.answers}
            score={page.score}
            onNavigate={navigate}
            onHome={goHome}
          />
        );

      case 'quem-somos': {
        const { section } = page;
        if (section === 'fontes') return <FontesPage onBack={goBack} onHome={goHome} />;
        if (section === 'contato') return <ContatoPage onBack={goBack} onHome={goHome} />;
        if (section === 'aviso') return <AvisoPage onBack={goBack} onHome={goHome} />;
        if (section === 'instituicao') return <InstituicaoPage onBack={goBack} onHome={goHome} />;
        return (
          <QuemSomosPage
            section={section as 'sobre' | 'missao' | 'equipe'}
            onBack={goBack}
            onHome={goHome}
          />
        );
      }

      default:
        return <HomePage onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F6F9]">
      <Header onHome={goHome} onNavigate={navigate} currentPage={page} />
      <SubNav onNavigate={navigate} />

      {/* Offset for fixed header (64px) + subheader (44px) = 108px */}
      <main key={pageKey} className={`flex-1 pt-[108px] ${!isLoading ? 'page-enter' : ''}`}>
        {renderPage()}
      </main>

      {!isLoading && <Footer onNavigate={navigate} />}
    </div>
  );
}
